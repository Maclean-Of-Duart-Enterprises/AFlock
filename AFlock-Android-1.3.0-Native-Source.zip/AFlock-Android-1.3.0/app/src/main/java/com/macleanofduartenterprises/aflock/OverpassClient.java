package com.macleanofduartenterprises.aflock;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Small, shared Overpass transport with polite request serialization and public-instance failover.
 * Queries are read-only, so retrying them against a different global instance is safe.
 */
public final class OverpassClient {
    private static final String USER_AGENT =
            "AFlock/1.3.0 (contact: office@macleanofduartenterprises.com)";
    private static final String[] ENDPOINTS = {
            "https://overpass.private.coffee/api/interpreter",
            "https://overpass-api.de/api/interpreter",
            "https://maps.mail.ru/osm/tools/overpass/api/interpreter"
    };
    private static final long MINIMUM_REQUEST_INTERVAL_MILLIS = 2_000L;
    private static final long DEFAULT_RATE_LIMIT_MILLIS = 60_000L;
    private static final long DEFAULT_TRANSIENT_FAILURE_MILLIS = 30_000L;
    private static final long MAXIMUM_COOLDOWN_MILLIS = 24L * 60L * 60L * 1_000L;
    private static final ReentrantLock REQUEST_LOCK = new ReentrantLock(true);
    private static final Map<String, Long> COOLDOWN_UNTIL = new HashMap<>();
    private static long lastRequestStartedAt;

    private OverpassClient() {
    }

    public static Response execute(
            String query,
            int connectTimeoutMillis,
            int readTimeoutMillis,
            int maximumResponseBytes,
            ProgressListener progressListener
    ) throws IOException {
        if (query == null || query.trim().isEmpty()) {
            throw new IllegalArgumentException("Overpass query must not be empty");
        }
        if (maximumResponseBytes <= 0) {
            throw new IllegalArgumentException("Maximum response size must be positive");
        }

        if (!REQUEST_LOCK.tryLock()) {
            notifyProgress(progressListener, "Waiting for the current map-data request to finish…");
            REQUEST_LOCK.lock();
        }
        try {
            return executeLocked(
                    query,
                    connectTimeoutMillis,
                    readTimeoutMillis,
                    maximumResponseBytes,
                    progressListener
            );
        } finally {
            REQUEST_LOCK.unlock();
        }
    }

    private static Response executeLocked(
            String query,
            int connectTimeoutMillis,
            int readTimeoutMillis,
            int maximumResponseBytes,
            ProgressListener progressListener
    ) throws IOException {
        boolean sawRateLimit = false;
        boolean attemptedEndpoint = false;
        int lastStatusCode = -1;
        IOException lastFailure = null;
        long now = System.currentTimeMillis();

        for (int index = 0; index < ENDPOINTS.length; index++) {
            String endpoint = ENDPOINTS[index];
            Long cooldown = COOLDOWN_UNTIL.get(endpoint);
            if (cooldown != null && cooldown > now) {
                continue;
            }
            attemptedEndpoint = true;
            waitForRequestSlot();
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(endpoint).openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(connectTimeoutMillis);
                connection.setReadTimeout(readTimeoutMillis);
                connection.setDoOutput(true);
                connection.setUseCaches(false);
                connection.setRequestProperty(
                        "Content-Type",
                        "application/x-www-form-urlencoded; charset=UTF-8"
                );
                connection.setRequestProperty("Accept", "application/json");
                connection.setRequestProperty("User-Agent", USER_AGENT);
                byte[] payload = ("data=" + URLEncoder.encode(query, "UTF-8"))
                        .getBytes(StandardCharsets.UTF_8);
                connection.setFixedLengthStreamingMode(payload.length);
                try (OutputStream output = connection.getOutputStream()) {
                    output.write(payload);
                }

                int statusCode = connection.getResponseCode();
                lastStatusCode = statusCode;
                if (statusCode == HttpURLConnection.HTTP_OK) {
                    byte[] body = readBounded(connection.getInputStream(), maximumResponseBytes);
                    COOLDOWN_UNTIL.remove(endpoint);
                    return new Response(body, new URL(endpoint).getHost());
                }

                if (!isRetryableStatus(statusCode)) {
                    throw new OverpassException(
                            "The map-data request was rejected (HTTP " + statusCode + ").",
                            0L,
                            statusCode
                    );
                }

                long cooldownMillis;
                if (statusCode == 429) {
                    sawRateLimit = true;
                    cooldownMillis = parseRetryAfterMillis(
                            connection.getHeaderField("Retry-After"),
                            System.currentTimeMillis(),
                            DEFAULT_RATE_LIMIT_MILLIS
                    );
                } else {
                    cooldownMillis = DEFAULT_TRANSIENT_FAILURE_MILLIS;
                }
                COOLDOWN_UNTIL.put(endpoint, System.currentTimeMillis() + cooldownMillis);
                if (index + 1 < ENDPOINTS.length) {
                    notifyProgress(
                            progressListener,
                            "Map-data service " + (index + 1) + " is busy; switching automatically…"
                    );
                }
            } catch (OverpassException failure) {
                throw failure;
            } catch (SocketTimeoutException failure) {
                lastFailure = failure;
                COOLDOWN_UNTIL.put(
                        endpoint,
                        System.currentTimeMillis() + DEFAULT_TRANSIENT_FAILURE_MILLIS
                );
                if (index + 1 < ENDPOINTS.length) {
                    notifyProgress(progressListener, "Map-data service timed out; trying a backup…");
                }
            } catch (IOException failure) {
                lastFailure = failure;
                COOLDOWN_UNTIL.put(
                        endpoint,
                        System.currentTimeMillis() + DEFAULT_TRANSIENT_FAILURE_MILLIS
                );
                if (index + 1 < ENDPOINTS.length) {
                    notifyProgress(progressListener, "Map-data service is unavailable; trying a backup…");
                }
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
            now = System.currentTimeMillis();
        }

        long retryAfterSeconds = secondsUntilNextEndpoint(System.currentTimeMillis());
        if (sawRateLimit || !attemptedEndpoint) {
            throw new OverpassException(
                    "All map-data services are busy. Automatic failover was attempted; retry in "
                            + retryAfterSeconds + " seconds.",
                    retryAfterSeconds,
                    lastStatusCode
            );
        }
        String suffix = lastFailure == null || lastFailure.getMessage() == null
                ? ""
                : " " + lastFailure.getMessage();
        throw new OverpassException(
                "Map-data services could not be reached. Check the connection and retry." + suffix,
                retryAfterSeconds,
                lastStatusCode
        );
    }

    private static byte[] readBounded(InputStream source, int maximumResponseBytes) throws IOException {
        try (InputStream input = source; ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[64 * 1024];
            int length;
            while ((length = input.read(buffer)) != -1) {
                if (bytes.size() > maximumResponseBytes - length) {
                    throw new OverpassException(
                            "The map-data response is too large; zoom in and try again.",
                            0L,
                            HttpURLConnection.HTTP_OK
                    );
                }
                bytes.write(buffer, 0, length);
            }
            return bytes.toByteArray();
        }
    }

    private static void waitForRequestSlot() throws InterruptedIOException {
        long waitMillis = Math.max(
                0L,
                lastRequestStartedAt + MINIMUM_REQUEST_INTERVAL_MILLIS - System.currentTimeMillis()
        );
        if (waitMillis > 0L) {
            try {
                Thread.sleep(waitMillis);
            } catch (InterruptedException interrupted) {
                Thread.currentThread().interrupt();
                throw new InterruptedIOException("Map-data request was interrupted");
            }
        }
        lastRequestStartedAt = System.currentTimeMillis();
    }

    static boolean isRetryableStatus(int statusCode) {
        return statusCode == 408
                || statusCode == 429
                || statusCode == 500
                || statusCode == 502
                || statusCode == 503
                || statusCode == 504;
    }

    static long parseRetryAfterMillis(String value, long nowMillis, long fallbackMillis) {
        if (value == null || value.trim().isEmpty()) {
            return clampCooldown(fallbackMillis);
        }
        String trimmed = value.trim();
        try {
            long seconds = Long.parseLong(trimmed);
            if (seconds <= 0L) {
                return 1_000L;
            }
            if (seconds > MAXIMUM_COOLDOWN_MILLIS / 1_000L) {
                return MAXIMUM_COOLDOWN_MILLIS;
            }
            return seconds * 1_000L;
        } catch (NumberFormatException ignored) {
            SimpleDateFormat format = new SimpleDateFormat(
                    "EEE, dd MMM yyyy HH:mm:ss zzz",
                    Locale.US
            );
            format.setLenient(false);
            format.setTimeZone(TimeZone.getTimeZone("GMT"));
            try {
                Date date = format.parse(trimmed);
                if (date == null) {
                    return clampCooldown(fallbackMillis);
                }
                return clampCooldown(Math.max(1_000L, date.getTime() - nowMillis));
            } catch (ParseException ignoredDate) {
                return clampCooldown(fallbackMillis);
            }
        }
    }

    private static long clampCooldown(long value) {
        return Math.max(1_000L, Math.min(MAXIMUM_COOLDOWN_MILLIS, value));
    }

    private static long secondsUntilNextEndpoint(long nowMillis) {
        long earliest = Long.MAX_VALUE;
        for (String endpoint : ENDPOINTS) {
            Long cooldown = COOLDOWN_UNTIL.get(endpoint);
            if (cooldown == null || cooldown <= nowMillis) {
                return 1L;
            }
            earliest = Math.min(earliest, cooldown);
        }
        if (earliest == Long.MAX_VALUE) {
            return 1L;
        }
        return Math.max(1L, (earliest - nowMillis + 999L) / 1_000L);
    }

    static List<String> endpointsForTests() {
        ArrayList<String> copy = new ArrayList<>();
        Collections.addAll(copy, ENDPOINTS);
        return Collections.unmodifiableList(copy);
    }

    static void resetStateForTests() {
        COOLDOWN_UNTIL.clear();
        lastRequestStartedAt = 0L;
    }

    private static void notifyProgress(ProgressListener listener, String message) {
        if (listener != null) {
            listener.onProgress(message);
        }
    }

    public interface ProgressListener {
        void onProgress(String message);
    }

    public static final class Response {
        private final byte[] body;
        private final String host;

        Response(byte[] body, String host) {
            this.body = body;
            this.host = host;
        }

        public byte[] getBody() {
            return body;
        }

        public String getHost() {
            return host;
        }
    }

    public static final class OverpassException extends IOException {
        private final long retryAfterSeconds;
        private final int statusCode;

        OverpassException(String message, long retryAfterSeconds, int statusCode) {
            super(message);
            this.retryAfterSeconds = retryAfterSeconds;
            this.statusCode = statusCode;
        }

        public long getRetryAfterSeconds() {
            return retryAfterSeconds;
        }

        public int getStatusCode() {
            return statusCode;
        }
    }
}
