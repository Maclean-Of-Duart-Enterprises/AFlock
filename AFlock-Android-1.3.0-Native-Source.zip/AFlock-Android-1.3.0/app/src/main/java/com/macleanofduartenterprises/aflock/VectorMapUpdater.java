package com.macleanofduartenterprises.aflock;

import android.content.Context;

import org.maplibre.android.MapLibre;
import org.maplibre.android.net.ConnectivityReceiver;
import org.maplibre.android.offline.OfflineManager;
import org.maplibre.android.offline.OfflineRegion;
import org.maplibre.android.offline.OfflineRegionError;
import org.maplibre.android.offline.OfflineRegionStatus;

import java.util.concurrent.atomic.AtomicInteger;

/** Revalidates cached vector resources and resumes only missing/changed downloads. */
public final class VectorMapUpdater {
    private VectorMapUpdater() {
    }

    public static void updateAll(Context context, Callback callback) {
        Context appContext = context.getApplicationContext();
        if (appContext.getSharedPreferences("vector_map", Context.MODE_PRIVATE)
                .getBoolean("offline", false)) {
            callback.onFinished(0, 0, "Strict offline mode is enabled; no network update was attempted.");
            return;
        }

        MapLibre.getInstance(appContext);
        ConnectivityReceiver.instance(appContext).setConnected(true);
        OfflineManager.getInstance(appContext).listOfflineRegions(new OfflineManager.ListOfflineRegionsCallback() {
            @Override
            public void onList(OfflineRegion[] regions) {
                if (regions == null || regions.length == 0) {
                    callback.onFinished(0, 0, "No downloaded vector regions need updating.");
                    return;
                }
                AtomicInteger remaining = new AtomicInteger(regions.length);
                AtomicInteger queued = new AtomicInteger();
                AtomicInteger errors = new AtomicInteger();
                for (OfflineRegion region : regions) {
                    OfflineRegionMetadata metadata = OfflineRegionMetadata.parse(region.getMetadata());
                    callback.onProgress("Revalidating " + metadata.name + "…");
                    region.invalidate(new OfflineRegion.OfflineRegionInvalidateCallback() {
                        @Override
                        public void onInvalidate() {
                            queued.incrementAndGet();
                            OfflineRegionMetadata updated = metadata.withUpdateRequestedNow();
                            region.updateMetadata(updated.toBytes(), new OfflineRegion.OfflineRegionUpdateMetadataCallback() {
                                @Override
                                public void onUpdate(byte[] bytes) {
                                    // Metadata is informational; the resource refresh is already queued.
                                }

                                @Override
                                public void onError(String error) {
                                    // Do not fail a map update because its timestamp could not be written.
                                }
                            });
                            region.setObserver(new OfflineRegion.OfflineRegionObserver() {
                                @Override
                                public void onStatusChanged(OfflineRegionStatus status) {
                                    if (status != null && status.isComplete()) {
                                        region.setDownloadState(OfflineRegion.STATE_INACTIVE);
                                    }
                                }

                                @Override
                                public void onError(OfflineRegionError error) {
                                    region.setDownloadState(OfflineRegion.STATE_INACTIVE);
                                }

                                @Override
                                public void mapboxTileCountLimitExceeded(long limit) {
                                    region.setDownloadState(OfflineRegion.STATE_INACTIVE);
                                }
                            });
                            region.setDownloadState(OfflineRegion.STATE_ACTIVE);
                            finishOne(remaining, queued, errors, callback);
                        }

                        @Override
                        public void onError(String error) {
                            errors.incrementAndGet();
                            finishOne(remaining, queued, errors, callback);
                        }
                    });
                }
            }

            @Override
            public void onError(String error) {
                callback.onFinished(0, 1, "Could not list offline regions: " + error);
            }
        });
    }

    private static void finishOne(
            AtomicInteger remaining,
            AtomicInteger queued,
            AtomicInteger errors,
            Callback callback
    ) {
        if (remaining.decrementAndGet() == 0) {
            String message = queued.get() + " region update(s) queued using cache revalidation";
            if (errors.get() > 0) {
                message += "; " + errors.get() + " region(s) could not be queued";
            }
            message += ". Unchanged resources are retained.";
            callback.onFinished(queued.get(), errors.get(), message);
        }
    }

    public interface Callback {
        void onProgress(String message);

        void onFinished(int queued, int errors, String message);
    }
}
