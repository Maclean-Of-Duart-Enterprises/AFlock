package com.macleanofduartenterprises.aflock;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.FrameLayout;

abstract class ThemedActivity extends Activity {
    @Override
    protected void onCreate(Bundle state) {
        ThemeManager.apply(this);
        super.onCreate(state);
        ThemeManager.styleSystemBars(this);
    }

    @Override
    public void setContentView(View content) {
        FrameLayout safeFrame = new FrameLayout(this);
        safeFrame.setBackgroundColor(ThemeManager.borderColor(this));
        content.setBackgroundColor(ThemeManager.windowBackground(this));
        safeFrame.addView(content, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        final int border = dp(4);
        safeFrame.setPadding(0, border, 0, border);
        safeFrame.setOnApplyWindowInsetsListener((view, insets) -> {
            int left;
            int top;
            int right;
            int bottom;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                left = bars.left;
                top = bars.top;
                right = bars.right;
                bottom = bars.bottom;
            } else {
                left = insets.getSystemWindowInsetLeft();
                top = insets.getSystemWindowInsetTop();
                right = insets.getSystemWindowInsetRight();
                bottom = insets.getSystemWindowInsetBottom();
            }
            view.setPadding(left, top + border, right, bottom + border);
            return insets;
        });
        super.setContentView(safeFrame);
        safeFrame.requestApplyInsets();
    }

    int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
