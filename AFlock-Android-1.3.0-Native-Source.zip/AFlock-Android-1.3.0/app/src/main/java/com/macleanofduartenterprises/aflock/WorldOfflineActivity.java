package com.macleanofduartenterprises.aflock;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.StatFs;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import org.maplibre.android.MapLibre;
import org.maplibre.android.geometry.LatLngBounds;
import org.maplibre.android.offline.OfflineManager;
import org.maplibre.android.offline.OfflineRegion;
import org.maplibre.android.offline.OfflineRegionError;
import org.maplibre.android.offline.OfflineRegionStatus;
import org.maplibre.android.offline.OfflineTilePyramidRegionDefinition;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Global catalog that covers all Web-Mercator coordinates without depending on a remote catalog. */
public final class WorldOfflineActivity extends ThemedActivity {
    private final Map<String, OfflineRegion> installedByStableId = new HashMap<>();
    private final List<String> labels = new ArrayList<>();
    private List<WorldRegionCatalog.WorldRegion> regions = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private TextView status;
    private Spinner zoom;
    private SharedPreferences preferences;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        MapLibre.getInstance(this);
        preferences = getSharedPreferences("vector_map", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(16, 12, 16, 12);

        TextView explanation = new TextView(this);
        explanation.setText(
                "Worldwide offline atlas: download the low-detail planet overview once, then add only the "
                        + "detail zones you need. The 72-zone catalog covers every coordinate supported by Web Mercator. "
                        + "Detailed downloads use the HTTPS vector style/provider you configure."
        );
        root.addView(explanation);

        Button style = new Button(this);
        style.setText("Set detailed-map style URL");
        root.addView(style);

        LinearLayout optionRow = new LinearLayout(this);
        zoom = new Spinner(this);
        String[] zoomChoices = {"Detail through zoom 8", "Detail through zoom 10", "Detail through zoom 12", "Detail through zoom 14"};
        zoom.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, zoomChoices));
        zoom.setSelection(2);
        Button overview = new Button(this);
        overview.setText("Download world overview");
        optionRow.addView(zoom, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        optionRow.addView(overview);
        root.addView(optionRow);

        status = new TextView(this);
        status.setPadding(8, 10, 8, 10);
        root.addView(status);

        ListView list = new ListView(this);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, labels);
        list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1
        ));
        setContentView(root);

        style.setOnClickListener(view -> promptForStyle());
        overview.setOnClickListener(view -> downloadOrManage(WorldRegionCatalog.worldOverview()));
        list.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < regions.size()) {
                downloadOrManage(regions.get(position));
            }
        });
        zoom.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view, int position, long id) {
                rebuildLabels();
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {
            }
        });
        refreshInstalled();
    }

    private int selectedMaximumZoom() {
        int[] values = {8, 10, 12, 14};
        return values[Math.max(0, Math.min(values.length - 1, zoom.getSelectedItemPosition()))];
    }

    private void rebuildLabels() {
        regions = WorldRegionCatalog.detailedRegions(selectedMaximumZoom());
        labels.clear();
        for (WorldRegionCatalog.WorldRegion region : regions) {
            labels.add((installedByStableId.containsKey(region.id) ? "✓ " : "○ ")
                    + region.name + " · z" + (int) region.minimumZoom + "–" + (int) region.maximumZoom);
        }
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
    }

    private void refreshInstalled() {
        OfflineManager.getInstance(this).listOfflineRegions(new OfflineManager.ListOfflineRegionsCallback() {
            @Override
            public void onList(OfflineRegion[] offlineRegions) {
                installedByStableId.clear();
                if (offlineRegions != null) {
                    for (OfflineRegion region : offlineRegions) {
                        OfflineRegionMetadata metadata = OfflineRegionMetadata.parse(region.getMetadata());
                        if (!metadata.stableId.isEmpty()) {
                            installedByStableId.put(metadata.stableId, region);
                        }
                    }
                }
                rebuildLabels();
                boolean overviewInstalled = installedByStableId.containsKey("world_overview");
                status.setText((overviewInstalled ? "World overview installed. " : "World overview not yet installed. ")
                        + installedByStableId.size() + " vector region(s) currently stored."
                        + " Available storage: " + availableStorageMiB() + " MiB.");
            }

            @Override
            public void onError(String error) {
                status.setText("Could not read offline vector catalog: " + error);
            }
        });
    }

    private void promptForStyle() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("https://provider.example/style.json");
        input.setText(preferences.getString("style", ""));
        new AlertDialog.Builder(this)
                .setTitle("Detailed vector style")
                .setMessage("Use a style whose tile provider expressly permits offline-region downloads. "
                        + "AFlock does not bulk-download OpenStreetMap's public raster servers.")
                .setView(input)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", (dialog, which) -> {
                    String value = input.getText().toString().trim();
                    if (!value.startsWith("https://")) {
                        status.setText("A valid HTTPS style URL is required for detailed downloads.");
                        return;
                    }
                    preferences.edit().putString("style", value).apply();
                    status.setText("Detailed-map style saved. Select a region to download it.");
                })
                .show();
    }

    private void downloadOrManage(WorldRegionCatalog.WorldRegion region) {
        OfflineRegion installed = installedByStableId.get(region.id);
        if (installed != null) {
            new AlertDialog.Builder(this)
                    .setTitle(region.name)
                    .setMessage("This region is installed. Revalidate it to fetch only stale or changed resources, or delete it.")
                    .setNegativeButton("Close", null)
                    .setNeutralButton("Delete", (dialog, which) -> installed.delete(new OfflineRegion.OfflineRegionDeleteCallback() {
                        @Override
                        public void onDelete() {
                            status.setText(region.name + " deleted.");
                            refreshInstalled();
                        }

                        @Override
                        public void onError(String error) {
                            status.setText("Delete failed: " + error);
                        }
                    }))
                    .setPositiveButton("Incremental update", (dialog, which) -> updateOne(installed, region.name))
                    .show();
            return;
        }

        String styleUrl = preferences.getString("style", "").trim();
        if (!styleUrl.startsWith("https://")) {
            status.setText("Set an HTTPS detailed-map style before downloading vector regions.");
            promptForStyle();
            return;
        }
        String warning = region.id.equals("world_overview")
                ? "Download the complete planet at zoom levels 0–5? Actual size depends on the selected style."
                : "Download this detail zone through zoom " + (int) region.maximumZoom
                + "? Higher zoom levels can consume substantial storage and provider bandwidth.";
        new AlertDialog.Builder(this)
                .setTitle(region.name)
                .setMessage(warning + "\n\nContinue only if the selected provider permits offline downloads.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Download", (dialog, which) -> createRegion(region, styleUrl))
                .show();
    }

    private void createRegion(WorldRegionCatalog.WorldRegion region, String styleUrl) {
        if (availableStorageMiB() < 512L) {
            status.setText("At least 512 MiB of free storage is required before starting a vector-region download.");
            return;
        }
        LatLngBounds bounds = LatLngBounds.from(region.north, region.east, region.south, region.west);
        OfflineTilePyramidRegionDefinition definition = new OfflineTilePyramidRegionDefinition(
                styleUrl,
                bounds,
                region.minimumZoom,
                region.maximumZoom,
                getResources().getDisplayMetrics().density
        );
        OfflineRegionMetadata metadata = OfflineRegionMetadata.create(
                region.id.equals("world_overview") ? "world-overview" : "world-detail",
                region.id,
                region.name,
                styleUrl
        );
        status.setText("Creating " + region.name + "…");
        OfflineManager.getInstance(this).createOfflineRegion(
                definition,
                metadata.toBytes(),
                new OfflineManager.CreateOfflineRegionCallback() {
                    @Override
                    public void onCreate(OfflineRegion offlineRegion) {
                        observeDownload(offlineRegion, region.name);
                        offlineRegion.setDownloadState(OfflineRegion.STATE_ACTIVE);
                        installedByStableId.put(region.id, offlineRegion);
                        rebuildLabels();
                    }

                    @Override
                    public void onError(String error) {
                        status.setText("Could not create offline region: " + error);
                    }
                }
        );
    }

    private void updateOne(OfflineRegion region, String name) {
        if (preferences.getBoolean("offline", false)) {
            status.setText("Disable strict offline mode before requesting an update.");
            return;
        }
        status.setText("Revalidating " + name + "…");
        region.invalidate(new OfflineRegion.OfflineRegionInvalidateCallback() {
            @Override
            public void onInvalidate() {
                OfflineRegionMetadata updated = OfflineRegionMetadata.parse(region.getMetadata()).withUpdateRequestedNow();
                region.updateMetadata(updated.toBytes(), new OfflineRegion.OfflineRegionUpdateMetadataCallback() {
                    @Override
                    public void onUpdate(byte[] bytes) {
                    }

                    @Override
                    public void onError(String error) {
                    }
                });
                observeDownload(region, name);
                region.setDownloadState(OfflineRegion.STATE_ACTIVE);
            }

            @Override
            public void onError(String error) {
                status.setText("Update could not start: " + error);
            }
        });
    }

    private void observeDownload(OfflineRegion region, String name) {
        region.setObserver(new OfflineRegion.OfflineRegionObserver() {
            @Override
            public void onStatusChanged(OfflineRegionStatus downloadStatus) {
                if (downloadStatus == null) {
                    return;
                }
                long complete = downloadStatus.getCompletedResourceCount();
                long required = downloadStatus.getRequiredResourceCount();
                String progress = required > 0 && downloadStatus.isRequiredResourceCountPrecise()
                        ? String.format(Locale.getDefault(), "%.1f%%", 100.0 * complete / required)
                        : complete + " resources";
                status.setText(name + ": " + progress + " · "
                        + downloadStatus.getCompletedResourceSize() / 1_048_576L + " MiB");
                if (downloadStatus.isComplete()) {
                    region.setDownloadState(OfflineRegion.STATE_INACTIVE);
                    status.setText(name + " is complete and ready offline.");
                    refreshInstalled();
                }
            }

            @Override
            public void onError(OfflineRegionError error) {
                status.setText("Offline download error: " + error.getMessage());
            }

            @Override
            public void mapboxTileCountLimitExceeded(long limit) {
                region.setDownloadState(OfflineRegion.STATE_INACTIVE);
                status.setText("Provider tile limit reached: " + limit);
            }
        });
    }

    private long availableStorageMiB() {
        return new StatFs(getFilesDir().getAbsolutePath()).getAvailableBytes() / 1_048_576L;
    }
}
