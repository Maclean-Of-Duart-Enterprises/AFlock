package com.macleanofduartenterprises.aflock;
import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.util.*;
/** Search the on-device cache without network access. */
public class OfflineSearchActivity extends ThemedActivity {
 private final ArrayList<JSONObject> records=new ArrayList<>();
 private final ArrayList<JSONObject> results=new ArrayList<>();
 private ArrayAdapter<String> adapter;private TextView summary;
 @Override public void onCreate(Bundle state){super.onCreate(state);
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
  EditText query=new EditText(this);query.setSingleLine(true);query.setHint("Name, source ID, type, status, or feature");
  Button search=new Button(this);search.setText("Search offline");summary=new TextView(this);
  ListView list=new ListView(this);adapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,new ArrayList<>());list.setAdapter(adapter);
  root.addView(query);root.addView(search);root.addView(summary);root.addView(list,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
  try {File file=new File(getFilesDir(),"records.json");if(file.exists()){
   ByteArrayOutputStream output=new ByteArrayOutputStream();try(InputStream input=new FileInputStream(file)){byte[] buffer=new byte[8192];int n;while((n=input.read(buffer))!=-1){output.write(buffer,0,n);if(output.size()>50000000)throw new IOException("Cache exceeds 50 MB");}}
   JSONArray array=new JSONArray(output.toString("UTF-8"));for(int i=0;i<array.length();i++){JSONObject obj=array.optJSONObject(i);if(obj!=null)records.add(obj);}
  }}catch(Exception e){summary.setText("Could not read cache: "+e.getMessage());}
  search.setOnClickListener(v->filter(query.getText().toString()));
  list.setOnItemClickListener((parent,view,position,id)->showDetails(results.get(position)));filter("");
 }
 private void filter(String query){String needle=query.trim().toLowerCase(Locale.ROOT);results.clear();adapter.clear();
  for(JSONObject item:records){String searchable=(item.optString("name")+" "+item.optString("operator")+" "+item.optString("kind")+" "+item.optString("status")+" "+item.optString("source")+" "+item.optString("sourceId")+" "+item.optString("osmId")+" "+item.optJSONObject("tags")).toLowerCase(Locale.ROOT);
   if(searchable.contains(needle)){results.add(item);String status=item.optString("status");adapter.add(item.optString("name","Unnamed device")+" — "+item.optString("kind")+(status.isEmpty()?"":" ("+status+")"));}}
  summary.setText(results.size()+" matches / "+records.size()+" saved records. No network required.");adapter.notifyDataSetChanged();
 }
 private void showDetails(JSONObject item){
  String source=item.optString("source",item.optString("osmType").isEmpty()?"saved":"openstreetmap");
  JSONObject tags=item.optJSONObject("tags");if(tags==null)tags=new JSONObject();
  StringBuilder message=new StringBuilder();
  message.append("Type: ").append(item.optString("kind","Unspecified"));
  String status=item.optString("status");if(!status.isEmpty())message.append("\nStatus: ").append(status);
  message.append("\nActive: ").append(item.has("active")?item.optBoolean("active")?"yes":"no":item.optBoolean("disused")?"no":"unknown");
  message.append("\nSource: ").append(source).append("\nSource ID: ").append(item.optString("sourceId"));
  message.append("\nCoordinates: ").append(item.optDouble("lat")).append(", ").append(item.optDouble("lon"));
  if(tags.optBoolean("unique",false)){
   message.append("\n\nUnique Cameras review\nCategories: ").append(tags.optString("uniqueCategories"));
   message.append("\nNote: ").append(tags.optString("uniqueNote"));
  }
  int cluster=tags.optInt("coLocatedCount",1);if(cluster>1){
   message.append("\nNearby cluster: ").append(cluster).append(" devices");
   message.append("\nCoordinate caution: clustered points may be generalized or placeholders.");
  }
  message.append("\n\nMetadata: ").append(tags);
  AlertDialog.Builder builder=new AlertDialog.Builder(this).setTitle(item.optString("name","Device"))
          .setMessage(message.toString()).setPositiveButton("Close",null);
  String sourceUrl=item.optString("sourceUrl");if(!sourceUrl.isEmpty())builder.setNeutralButton("Open source",(dialog,which)->{
   try{startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW,android.net.Uri.parse(sourceUrl)));}catch(Exception ignored){}
  });
  builder.show();
 }
}
