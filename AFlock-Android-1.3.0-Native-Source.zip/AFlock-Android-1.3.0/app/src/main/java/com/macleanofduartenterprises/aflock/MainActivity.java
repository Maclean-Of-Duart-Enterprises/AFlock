package com.macleanofduartenterprises.aflock;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;
import org.json.*;
import java.net.*;
import java.io.*;
import java.util.*;
import android.content.*;
import android.net.Uri;
import org.osmdroid.tileprovider.MapTileProviderBasic;
import org.osmdroid.tileprovider.modules.*;
import org.osmdroid.tileprovider.tilesource.*;

public class MainActivity extends ThemedActivity {
 MapView map; TextView status; boolean activeOnly=false; String searchText=""; String typeFilter="All"; final ArrayList<Camera> cameras=new ArrayList<>(); final Handler handler=new Handler();
 final ArrayList<Marker> markers=new ArrayList<>();
 final java.util.concurrent.atomic.AtomicBoolean loadInProgress=new java.util.concurrent.atomic.AtomicBoolean(false);
 static final int PICK_MAP=401; boolean offline=false; File offlineArchive; MapTileProviderBasic onlineProvider;
 String lastLoadSummary="Saved camera cache. Default live source: Flock Surveillance Map.";

 @Override public void onCreate(Bundle b){
  super.onCreate(b);
  Configuration.getInstance().setUserAgentValue(getPackageName()+"/1.3.0 (contact: office@macleanofduartenterprises.com)");

  LinearLayout layout=new LinearLayout(this);
  layout.setOrientation(LinearLayout.VERTICAL);

  LinearLayout header=new LinearLayout(this);
  header.setOrientation(LinearLayout.VERTICAL);
  header.setPadding(dp(4),dp(3),dp(4),dp(4));
  header.setBackgroundColor(ThemeManager.panelBackground(this));

  LinearLayout titleRow=new LinearLayout(this);
  titleRow.setGravity(Gravity.CENTER_VERTICAL);
  ImageButton settings=new ImageButton(this);
  settings.setImageResource(R.drawable.ic_settings);
  settings.setColorFilter(ThemeManager.primaryTextColor(this));
  settings.setBackgroundColor(Color.TRANSPARENT);
  settings.setContentDescription("Settings");
  settings.setTooltipText("Settings");
  settings.setPadding(dp(12),dp(12),dp(12),dp(12));
  titleRow.addView(settings,new LinearLayout.LayoutParams(dp(48),dp(48)));
  TextView title=new TextView(this);
  title.setText("AFlock map");
  title.setTextSize(20);
  title.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);
  title.setGravity(Gravity.CENTER_VERTICAL);
  titleRow.addView(title,new LinearLayout.LayoutParams(0,dp(48),1));
  header.addView(titleRow);

  LinearLayout searchRow=new LinearLayout(this);
  searchRow.setGravity(Gravity.CENTER_VERTICAL);
  EditText search=new EditText(this);
  search.setSingleLine(true);
  search.setHint("Search name, operator, type");
  Button apply=new Button(this);
  apply.setText("Search");
  searchRow.addView(search,new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1));
  searchRow.addView(apply);
  header.addView(searchRow);

  LinearLayout typeRow=new LinearLayout(this);
  typeRow.setGravity(Gravity.CENTER_VERTICAL);
  TextView typeLabel=new TextView(this);
  typeLabel.setText("Display type");
  typeLabel.setTextSize(16);
  typeLabel.setPadding(dp(8),0,dp(12),0);
  Spinner types=new Spinner(this);
  String[] choices={"All","ALPR","Camera / PTZ","Audio","Drone","Unique","Other"};
  types.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,choices));
  typeRow.addView(typeLabel);
  typeRow.addView(types,new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1));
  header.addView(typeRow);
  layout.addView(header);

  status=new TextView(this);
  status.setText("Move the map, open Settings, and choose Load cameras. Flock Surveillance is the default source.");
  status.setPadding(dp(12),dp(8),dp(12),dp(8));
  layout.addView(status);

  map=new MapView(this);
  map.setTileSource(TileSourceFactory.MAPNIK);
  map.setMultiTouchControls(true);
  onlineProvider=(MapTileProviderBasic)map.getTileProvider();
  offlineArchive=new File(getFilesDir(),"offline-map.zip");
  map.getController().setZoom(10.0);
  map.getController().setCenter(new GeoPoint(40.34,-76.42));
  layout.addView(map,new LinearLayout.LayoutParams(
          LinearLayout.LayoutParams.MATCH_PARENT,0,1));
  setContentView(layout);

  apply.setOnClickListener(v->{searchText=search.getText().toString().trim().toLowerCase(Locale.ROOT);render();});
  types.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){} public void onItemSelected(android.widget.AdapterView<?> p,View v,int position,long id){typeFilter=choices[position];render();}});
  settings.setOnClickListener(v->showSettings());
  loadSavedRecords();
  if(b==null)map.postDelayed(this::load,450L);
 }

 void showSettings(){
  ScrollView scroller=new ScrollView(this);
  LinearLayout panel=new LinearLayout(this);
  panel.setOrientation(LinearLayout.VERTICAL);
  panel.setPadding(dp(18),dp(8),dp(18),dp(18));
  scroller.addView(panel,new ScrollView.LayoutParams(
          ScrollView.LayoutParams.MATCH_PARENT,ScrollView.LayoutParams.WRAP_CONTENT));

  addSettingsSection(panel,"Appearance");
  RadioGroup themes=new RadioGroup(this);
  themes.setOrientation(RadioGroup.VERTICAL);
  RadioButton systemTheme=themeChoice("Use device theme",ThemeManager.SYSTEM);
  RadioButton lightTheme=themeChoice("Light",ThemeManager.LIGHT);
  RadioButton darkTheme=themeChoice("Dark",ThemeManager.DARK);
  themes.addView(systemTheme);
  themes.addView(lightTheme);
  themes.addView(darkTheme);
  String selectedTheme=ThemeManager.getChoice(this);
  if(ThemeManager.LIGHT.equals(selectedTheme))lightTheme.setChecked(true);
  else if(ThemeManager.DARK.equals(selectedTheme))darkTheme.setChecked(true);
  else systemTheme.setChecked(true);
  panel.addView(themes);

  AlertDialog dialog=new AlertDialog.Builder(this)
          .setTitle("Settings")
          .setView(scroller)
          .setNegativeButton("Close",null)
          .create();
  themes.setOnCheckedChangeListener((group,checkedId)->{
   View checked=group.findViewById(checkedId);
   if(checked!=null&&checked.getTag()!=null){
    ThemeManager.setChoice(this,checked.getTag().toString());
    dialog.dismiss();
    recreate();
   }
  });

  addSettingsSection(panel,"Map data");
  addSettingsButton(panel,dialog,"Load cameras for visible map",this::load);
  addSettingsButton(panel,dialog,"Refresh Flock Surveillance dataset",()->loadFlock(true));
  addSettingsButton(panel,dialog,"Camera source and Unique Cameras guide",this::showSourceInformation);
  addSettingsButton(panel,dialog,"Load OpenStreetMap supplementary cameras",this::loadOpenStreetMapOnly);
  addSettingsButton(panel,dialog,activeOnly?"Status filter: In-service only":"Status filter: All statuses",()->{activeOnly=!activeOnly;render();});
  addSettingsButton(panel,dialog,"Sync current map area",this::load);
  addSettingsButton(panel,dialog,"Enable daily surveillance sync",this::scheduleDailySync);
  addSettingsButton(panel,dialog,"Save records",this::saveRecords);

  addSettingsSection(panel,"Offline search and records");
  addSettingsButton(panel,dialog,"Offline address search",this::openOfflineAddressSearch);
  addSettingsButton(panel,dialog,"Search saved surveillance records",()->startActivity(new Intent(this,OfflineSearchActivity.class)));
  addSettingsButton(panel,dialog,"Reload synchronized records",this::loadSavedRecords);

  addSettingsSection(panel,"Offline maps");
  addSettingsButton(panel,dialog,"Map storage management",this::showStorageManagement);
  addSettingsButton(panel,dialog,"Verified offline map packages",()->startActivity(new Intent(this,PackageActivity.class)));
  addSettingsButton(panel,dialog,"Worldwide vector maps / offline regions",()->startActivity(new Intent(this,VectorMapActivity.class)));
  addSettingsButton(panel,dialog,"Download licensed map ZIP",this::promptMapDownload);
  addSettingsButton(panel,dialog,"Offline coverage",this::showCoverage);
  addSettingsButton(panel,dialog,"Import offline map",this::pickMap);
  addSettingsButton(panel,dialog,offline?"Switch to online map":"Enable offline raster map",()->{offline=!offline;setOfflineMode();});
  dialog.show();
 }

 RadioButton themeChoice(String label,String value){
  RadioButton choice=new RadioButton(this);
  choice.setId(View.generateViewId());
  choice.setText(label);
  choice.setTag(value);
  choice.setPadding(dp(4),dp(2),dp(4),dp(2));
  return choice;
 }

 void addSettingsSection(LinearLayout panel,String label){
  TextView heading=new TextView(this);
  heading.setText(label);
  heading.setTextSize(18);
  heading.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);
  heading.setPadding(dp(4),dp(14),dp(4),dp(4));
  panel.addView(heading);
 }

 void addSettingsButton(LinearLayout panel,AlertDialog dialog,String label,Runnable action){
  Button button=new Button(this);
  button.setText(label);
  button.setAllCaps(false);
  button.setOnClickListener(view->{dialog.dismiss();action.run();});
  panel.addView(button,new LinearLayout.LayoutParams(
          LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT));
 }

 void scheduleDailySync(){
  androidx.work.Constraints constraints=new androidx.work.Constraints.Builder()
          .setRequiredNetworkType(androidx.work.NetworkType.CONNECTED).build();
  androidx.work.PeriodicWorkRequest request=new androidx.work.PeriodicWorkRequest.Builder(
          SyncWorker.class,24,java.util.concurrent.TimeUnit.HOURS)
          .setConstraints(constraints).build();
  androidx.work.WorkManager.getInstance(this).enqueueUniquePeriodicWork(
          "surveillance-sync",androidx.work.ExistingPeriodicWorkPolicy.KEEP,request);
  getSharedPreferences("sync",0).edit()
          .putFloat("lat",(float)map.getMapCenter().getLatitude())
          .putFloat("lon",(float)map.getMapCenter().getLongitude()).apply();
  status.setText("Daily sync scheduled for current map center (approx. 10 km radius).");
 }
 void load(){loadFlock(false);}

 void loadFlock(boolean forceRefresh){
  if(offline){status.setText("Offline mode: displaying locally saved surveillance records.");return;}
  org.osmdroid.util.BoundingBox box=map.getBoundingBox();
  double south=box.getLatSouth(),west=box.getLonWest(),north=box.getLatNorth(),east=box.getLonEast();
  double longitudeSpan=east>=west?east-west:(180d-west)+(east+180d);
  if(north-south>2.5 || longitudeSpan>2.5){status.setText("Zoom in to a smaller area before loading cameras.");return;}
  if(!loadInProgress.compareAndSet(false,true)){status.setText("A map-data request is already running.");return;}
  status.setText(forceRefresh?"Refreshing Flock Surveillance camera data…":"Loading Flock Surveillance camera data…");
  FlockSurveillanceClient.Bounds bounds=new FlockSurveillanceClient.Bounds(south,west,north,east);
  new Thread(()->{
   try{
    FlockSurveillanceClient.Result result=FlockSurveillanceClient.loadVisible(
            this,bounds,forceRefresh,
            message->runOnUiThread(()->status.setText(message)));
    ArrayList<Camera> found=new ArrayList<>();
    for(FlockSurveillanceClient.Device device:result.devices){
     found.add(cameraFromRecord(device.toNormalizedRecord()));
    }
    runOnUiThread(()->{
     replaceVisibleRecords(bounds,found,"flocksurveillance.org");
     lastLoadSummary="Loaded "+found.size()+" Flock Surveillance devices from "
             +result.scannedRecords+" source records"
             +(result.uniqueRecords>0?"; "+result.uniqueRecords+" match the Unique Cameras review":"")+"."
             +(result.warning.isEmpty()?"":" "+result.warning);
     persistRecords();
     render();
    });
   }catch(Exception primaryError){
    runOnUiThread(()->status.setText("Flock Surveillance source unavailable; trying OpenStreetMap fallback…"));
    try{
     ArrayList<Camera> fallback=fetchOpenStreetMapCameras(
             south,west,north,east,
             message->runOnUiThread(()->status.setText(message)));
     runOnUiThread(()->{
      replaceVisibleRecords(bounds,fallback,"openstreetmap");
      lastLoadSummary="Flock Surveillance load failed ("+safeMessage(primaryError)
              +"). Showing "+fallback.size()+" OpenStreetMap fallback records.";
      persistRecords();
      render();
     });
    }catch(Exception fallbackError){
     runOnUiThread(()->status.setText("Camera load failed. Flock source: "
             +safeMessage(primaryError)+". OSM fallback: "+safeMessage(fallbackError)));
    }
   }finally{loadInProgress.set(false);}
  }).start();
 }

 void loadOpenStreetMapOnly(){
  if(offline){status.setText("Offline mode: displaying locally saved surveillance records.");return;}
  org.osmdroid.util.BoundingBox box=map.getBoundingBox();
  double south=box.getLatSouth(),west=box.getLonWest(),north=box.getLatNorth(),east=box.getLonEast();
  double longitudeSpan=east>=west?east-west:(180d-west)+(east+180d);
  if(north-south>2.5 || longitudeSpan>2.5){status.setText("Zoom in to a smaller area before loading cameras.");return;}
  if(!loadInProgress.compareAndSet(false,true)){status.setText("A map-data request is already running.");return;}
  status.setText("Loading supplementary OpenStreetMap surveillance records…");
  FlockSurveillanceClient.Bounds bounds=new FlockSurveillanceClient.Bounds(south,west,north,east);
  new Thread(()->{
   try{
    ArrayList<Camera> found=fetchOpenStreetMapCameras(
            south,west,north,east,
            message->runOnUiThread(()->status.setText(message)));
    runOnUiThread(()->{
     replaceVisibleRecords(bounds,found,"openstreetmap");
     lastLoadSummary="Loaded "+found.size()+" supplementary OpenStreetMap surveillance records.";
     persistRecords();
     render();
    });
   }catch(Exception error){
    runOnUiThread(()->status.setText("OpenStreetMap load failed: "+safeMessage(error)));
   }finally{loadInProgress.set(false);}
  }).start();
 }

 ArrayList<Camera> fetchOpenStreetMapCameras(
         double south,double west,double north,double east,
         OverpassClient.ProgressListener progress
 )throws Exception{
  String query="[out:json][timeout:25];(node[\"man_made\"=\"surveillance\"]("+south+","+west+","+north+","+east+");way[\"man_made\"=\"surveillance\"]("+south+","+west+","+north+","+east+"););out center 2000;";
  OverpassClient.Response response=OverpassClient.execute(query,15000,35000,10000000,progress);
  JSONArray elements=new JSONObject(new String(response.getBody(),"UTF-8")).getJSONArray("elements");
  ArrayList<Camera> found=new ArrayList<>();
  for(int i=0;i<elements.length();i++){
   JSONObject element=elements.getJSONObject(i),tags=element.optJSONObject("tags");if(tags==null)continue;
   JSONObject center=element.optJSONObject("center");
   double latitude=element.has("lat")?element.optDouble("lat"):center==null?Double.NaN:center.optDouble("lat");
   double longitude=element.has("lon")?element.optDouble("lon"):center==null?Double.NaN:center.optDouble("lon");
   if(Double.isNaN(latitude)||Double.isNaN(longitude))continue;
   Camera camera=new Camera();
   camera.point=new GeoPoint(latitude,longitude);
   camera.name=tags.optString("name","Unnamed surveillance device");
   camera.kind=tags.optString("surveillance:type",tags.optString("camera:type","Unspecified"));
   camera.operator=tags.optString("operator","Unknown");
   camera.disused="yes".equals(tags.optString("disused"))||"yes".equals(tags.optString("abandoned"));
   camera.active=!camera.disused;
   camera.status=camera.disused?"disused":"OSM community record";
   camera.osmType=element.optString("type","node");
   camera.osmId=element.optLong("id");
   camera.source="openstreetmap";
   camera.sourceId=camera.osmType+"/"+camera.osmId;
   camera.sourceUrl="https://www.openstreetmap.org/"+camera.sourceId;
   camera.tags=tags;
   found.add(camera);
  }
  return found;
 }

 void replaceVisibleRecords(FlockSurveillanceClient.Bounds bounds,List<Camera> found,String sourceToReplace){
  Iterator<Camera> iterator=cameras.iterator();
  while(iterator.hasNext()){
   Camera camera=iterator.next();
   if(sourceToReplace.equals(camera.source)
           &&bounds.contains(camera.point.getLatitude(),camera.point.getLongitude()))iterator.remove();
  }
  LinkedHashMap<String,Camera> merged=new LinkedHashMap<>();
  for(Camera camera:cameras)merged.put(cameraKey(camera),camera);
  for(Camera camera:found)merged.put(cameraKey(camera),camera);
  cameras.clear();
  cameras.addAll(merged.values());
 }

 String cameraKey(Camera camera){
  if(camera.sourceId!=null&&!camera.sourceId.isEmpty())return camera.source+"/"+camera.sourceId;
  if(camera.osmType!=null&&!camera.osmType.isEmpty())return "openstreetmap/"+camera.osmType+"/"+camera.osmId;
  return camera.source+"/"+camera.point.getLatitude()+"/"+camera.point.getLongitude()+"/"+camera.name;
 }

 static String safeMessage(Throwable error){return error.getMessage()==null?error.getClass().getSimpleName():error.getMessage();}

 void showSourceInformation(){
  String message="AFlock now uses the camera feed published by flocksurveillance.org as its default live source. The feed is cached on this device and refreshed at most every six hours unless you choose Refresh.\n\n"
          +"The Unique Cameras page is also read to add its review categories, notes, co-located-device count, and coordinate caution to matching records. A dense cluster can use generalized or placeholder coordinates; a point is a review lead, not proof of an exact device location.\n\n"
          +"OpenStreetMap remains available as a supplementary source and as a fallback if the default feed and its saved copy are unavailable. Source-site terms and underlying data licenses continue to apply.";
  new AlertDialog.Builder(this).setTitle("Camera data sources").setMessage(message)
          .setPositiveButton("Close",null)
          .setNeutralButton("Open map source",(dialog,which)->openUrl(FlockSurveillanceClient.MAP_URL))
          .setNegativeButton("Open Unique Cameras",(dialog,which)->openUrl(FlockSurveillanceClient.UNIQUE_URL))
          .show();
 }

 void openUrl(String url){
  try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}
  catch(Exception error){status.setText("No browser is available to open the source link.");}
 }

 void openOfflineAddressSearch(){org.osmdroid.util.BoundingBox box=map.getBoundingBox();Intent intent=new Intent(this,OfflineAddressSearchActivity.class);intent.putExtra("south",box.getLatSouth());intent.putExtra("west",box.getLonWest());intent.putExtra("north",box.getLatNorth());intent.putExtra("east",box.getLonEast());startActivity(intent);}
 void showStorageManagement(){
  File pending=new File(getFilesDir(),"offline-map.download");
  long sourceBytes=FlockSurveillanceClient.cachedDatasetBytes(this);
  String info="Flock Surveillance source cache: "+formatBytes(sourceBytes)
          +"\nOffline raster archive: "+formatBytes(offlineArchive.exists()?offlineArchive.length():0L)
          +"\nPartial raster download: "+formatBytes(pending.exists()?pending.length():0L)
          +"\nSaved camera records: "+formatBytes(new File(getFilesDir(),"records.json").length())
          +"\nOffline addresses: "+AddressDatabase.get(this).countAll()+" records";
  new AlertDialog.Builder(this).setTitle("Storage").setMessage(info)
          .setNegativeButton("Close",null)
          .setNeutralButton("Clear source cache",(dialog,which)->{
           FlockSurveillanceClient.clearCaches(this);
           status.setText("Flock Surveillance source cache cleared. Saved camera records remain available.");
          })
          .setPositiveButton("Delete raster files",(dialog,which)->{
           offline=false;offlineArchive.delete();pending.delete();setOfflineMode();
          }).show();
 }

 static String formatBytes(long bytes){
  if(bytes<=0)return "none";
  if(bytes>=1024L*1024L)return String.format(Locale.ROOT,"%.1f MB",bytes/(1024d*1024d));
  return Math.max(1L,bytes/1024L)+" KB";
 }
 void promptMapDownload(){
  EditText urlInput=new EditText(this);urlInput.setSingleLine(true);urlInput.setHint("https://provider.example/region.zip");
  new AlertDialog.Builder(this).setTitle("Download licensed offline map").setMessage("Paste a direct HTTPS URL to an osmdroid-compatible ZIP tile archive from a provider that expressly permits offline downloads. Do not use OpenStreetMap's public tile servers for bulk downloads. Large maps may require substantial storage.").setView(urlInput).setNegativeButton("Cancel",null).setPositiveButton("Download",(d,w)->downloadMap(urlInput.getText().toString().trim())).show();
 }
 void downloadMap(String urlString){
  if(!urlString.startsWith("https://")){status.setText("Only HTTPS downloads are supported.");return;}
  status.setText("Downloading licensed map package…");
  new Thread(()->{File tmp=new File(getFilesDir(),"offline-map.download");try{
   URL url=new URL(urlString);HttpURLConnection conn=(HttpURLConnection)url.openConnection();conn.setConnectTimeout(15000);conn.setReadTimeout(30000);conn.setInstanceFollowRedirects(false);
   if(tmp.exists()&&tmp.length()>0)conn.setRequestProperty("Range","bytes="+tmp.length()+"-");int response=conn.getResponseCode();if(response!=200&&response!=206)throw new IOException("HTTP "+response);boolean append=response==206;
   long total=conn.getContentLengthLong();if(total>2L*1024*1024*1024)throw new IOException("Archive exceeds 2 GB");
   try(InputStream in=conn.getInputStream();OutputStream out=new FileOutputStream(tmp,append)){byte[] b=new byte[65536];int n;long received=append?tmp.length():0;while((n=in.read(b))!=-1){received+=n;if(received>2L*1024*1024*1024)throw new IOException("Archive exceeds 2 GB");out.write(b,0,n);if(received%(8*1024*1024)<65536){final long progress=received;runOnUiThread(()->status.setText("Downloaded "+(progress/1048576)+" MB"));}}}
   if(!validTileZip(tmp))throw new IOException("Unsupported tile ZIP layout (expected zoom/x/y.png)");
   if(offlineArchive.exists()&&!offlineArchive.delete())throw new IOException("Could not replace existing map");if(!tmp.renameTo(offlineArchive))throw new IOException("Could not install archive");
   runOnUiThread(()->{status.setText("Map downloaded and verified. Enable Offline mode.");if(offline)setOfflineMode();});
  }catch(Exception ex){runOnUiThread(()->status.setText("Download interrupted (partial file retained for resume): "+ex.getMessage()));}}).start();
 }
 boolean validTileZip(File file)throws IOException{try(java.util.zip.ZipFile zip=new java.util.zip.ZipFile(file)){Enumeration<? extends java.util.zip.ZipEntry> entries=zip.entries();int count=0;while(entries.hasMoreElements()&&count++<200000){String name=entries.nextElement().getName();if(name.matches("(?:[^/]+/)?[0-9]+/[0-9]+/[0-9]+\\.(?:png|jpg|jpeg)"))return true;}return false;}}
 void showCoverage(){String message=offlineArchive.exists()?"Imported raster map archive: "+(offlineArchive.length()/1048576)+" MB. Coverage is limited to tiles in this archive.":"No offline raster archive installed.";message+="\n\nThe Vector maps screen includes a built-in low-detail worldwide overview plus a 72-zone detailed offline catalog.";new AlertDialog.Builder(this).setTitle("Offline map coverage").setMessage(message).setPositiveButton("OK",null).show();}
 void pickMap(){Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.setType("application/zip");intent.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(intent,PICK_MAP);}
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request!=PICK_MAP||result!=RESULT_OK||data==null)return;
  Uri uri=data.getData();status.setText("Importing map archive…");new Thread(()->{try{
   File tmp=new File(getFilesDir(),"offline-map.tmp");try(InputStream in=getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(tmp,false)){byte[] b=new byte[65536];int n;long size=0;while((n=in.read(b))!=-1){size+=n;if(size>2L*1024*1024*1024)throw new IOException("Archive exceeds 2 GB limit");out.write(b,0,n);}}
   boolean valid=false;try(java.util.zip.ZipFile z=new java.util.zip.ZipFile(tmp)){Enumeration<? extends java.util.zip.ZipEntry> entries=z.entries();int count=0;while(entries.hasMoreElements()&&count++<10000){String name=entries.nextElement().getName();if(name.matches("(?:[^/]+/)?[0-9]+/[0-9]+/[0-9]+\\.(?:png|jpg|jpeg)")){valid=true;break;}}}
   if(!valid)throw new IOException("Expected osmdroid ZIP tiles: zoom/x/y.png");if(offlineArchive.exists())offlineArchive.delete();if(!tmp.renameTo(offlineArchive))throw new IOException("Could not save map");runOnUiThread(()->{status.setText("Offline map imported. Select Offline mode.");if(offline)setOfflineMode();});
  }catch(Exception ex){runOnUiThread(()->status.setText("Import failed: "+ex.getMessage()));}}).start();}
 void setOfflineMode(){try{if(offline){if(!offlineArchive.exists()){status.setText("Import a compatible offline ZIP map first. Map tiles are not bundled.");offline=false;return;}
  XYTileSource source=new XYTileSource("Mapnik",0,19,256,".png",new String[]{});
  IArchiveFile archive=ArchiveFileFactory.getArchiveFile(offlineArchive);if(archive==null)throw new IOException("Unsupported offline archive");
  IArchiveFile[] archives=new IArchiveFile[]{archive};MapTileFileArchiveProvider archiveProvider=new MapTileFileArchiveProvider(new org.osmdroid.tileprovider.util.SimpleRegisterReceiver(this),source,archives);
  org.osmdroid.tileprovider.MapTileProviderArray provider=new org.osmdroid.tileprovider.MapTileProviderArray(source,null,new MapTileModuleProviderBase[]{archiveProvider});map.setTileProvider(provider);status.setText("Offline map enabled. Coverage depends on imported ZIP. No network map requests.");
 }else{map.setTileProvider(onlineProvider);status.setText("Online map enabled.");}map.invalidate();}catch(Exception e){status.setText("Offline map error: "+e.getMessage());offline=false;}}
 Camera cameraFromRecord(JSONObject record)throws JSONException{
  Camera camera=new Camera();
  camera.point=new GeoPoint(record.getDouble("lat"),record.getDouble("lon"));
  camera.name=record.optString("name","Unnamed surveillance device");
  camera.kind=record.optString("kind","Unspecified device");
  camera.operator=record.optString("operator","Unknown");
  camera.disused=record.optBoolean("disused",false);
  camera.active=record.has("active")?record.optBoolean("active"):!camera.disused;
  camera.status=record.optString("status",camera.disused?"disused":"saved record");
  camera.osmType=record.optString("osmType","");
  camera.osmId=record.optLong("osmId",0L);
  camera.tags=record.optJSONObject("tags");
  if(camera.tags==null)camera.tags=new JSONObject();
  camera.source=record.optString("source",camera.tags.optString("source",""));
  if(camera.source.isEmpty()&&!camera.osmType.isEmpty())camera.source="openstreetmap";
  if(camera.source.isEmpty())camera.source="saved";
  camera.sourceId=record.optString("sourceId","");
  if(camera.sourceId.isEmpty()&&!camera.osmType.isEmpty())camera.sourceId=camera.osmType+"/"+camera.osmId;
  camera.sourceUrl=record.optString("sourceUrl","");
  if(camera.sourceUrl.isEmpty()&&"openstreetmap".equals(camera.source))
   camera.sourceUrl="https://www.openstreetmap.org/"+camera.sourceId;
  return camera;
 }

 JSONObject cameraToRecord(Camera camera)throws JSONException{
  JSONObject record=new JSONObject();
  record.put("lat",camera.point.getLatitude());record.put("lon",camera.point.getLongitude());
  record.put("name",camera.name);record.put("kind",camera.kind);record.put("operator",camera.operator);
  record.put("status",camera.status);record.put("active",camera.active);record.put("disused",camera.disused);
  record.put("source",camera.source);record.put("sourceId",camera.sourceId);record.put("sourceUrl",camera.sourceUrl);
  record.put("osmType",camera.osmType);record.put("osmId",camera.osmId);record.put("tags",camera.tags);
  return record;
 }

 void persistRecords(){
  try{
   JSONArray records=new JSONArray();for(Camera camera:cameras)records.put(cameraToRecord(camera));
   try(OutputStream output=openFileOutput("records.json",MODE_PRIVATE)){
    output.write(records.toString().getBytes("UTF-8"));
   }
  }catch(Exception error){status.setText("Could not cache records: "+safeMessage(error));}
 }

 void loadSavedRecords(){
  cameras.clear();
  try(InputStream input=openFileInput("records.json")){
   ByteArrayOutputStream bytes=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int count;
   while((count=input.read(buffer))!=-1){bytes.write(buffer,0,count);if(bytes.size()>50000000)throw new IOException("Saved camera cache exceeds 50 MB");}
   JSONArray records=new JSONArray(bytes.toString("UTF-8"));
   for(int index=0;index<records.length();index++){
    JSONObject record=records.optJSONObject(index);if(record!=null)cameras.add(cameraFromRecord(record));
   }
   lastLoadSummary="Loaded "+cameras.size()+" saved camera records. Choose Load cameras to refresh the visible map.";
  }catch(FileNotFoundException ignored){
   lastLoadSummary="No saved camera records yet. Choose Load cameras to use the default Flock Surveillance source.";
  }catch(Exception error){lastLoadSummary="Could not read saved camera records: "+safeMessage(error);}
  render();
 }

 void saveRecords(){persistRecords();status.setText("Saved "+cameras.size()+" camera records for offline search.");}

 static class Camera {
  GeoPoint point;String name="",kind="",operator="",status="",source="",sourceId="",sourceUrl="",osmType="";
  long osmId;boolean disused;boolean active=true;JSONObject tags=new JSONObject();
 }

 String categoryFor(Camera camera){
  String text=(camera.kind+" "+camera.tags.optString("sourceType")+" "+camera.tags.optString("features")+" "+camera.name).toLowerCase(Locale.ROOT);
  boolean alpr=text.contains("readslicenseplates")||text.contains("alpr")||text.contains("lpr")||text.contains("license plate")||text.contains("falcon");
  boolean audio=text.contains("raven")||text.contains("audio")||text.contains("talkdown")||text.contains("speaker");
  boolean drone=text.contains("drone");
  boolean cameraOrPtz=text.contains("camera")||text.contains("ptz")||text.contains("wing")||text.contains("picard")||text.contains("condor")||text.contains("trailer")||text.contains("fixed")||text.contains("dome");
  if(alpr)return "ALPR";if(drone)return "Drone";if(audio)return "Audio";if(cameraOrPtz)return "Camera / PTZ";return "Other";
 }

 void render(){
  if(map==null)return;
  for(Marker marker:markers)map.getOverlays().remove(marker);markers.clear();
  int visible=0,flockCount=0,osmCount=0;
  for(Camera camera:cameras){
   String all=(camera.name+" "+camera.kind+" "+camera.operator+" "+camera.status+" "+camera.source+" "+camera.sourceId+" "+camera.tags).toLowerCase(Locale.ROOT);
   if(!all.contains(searchText))continue;if(activeOnly&&!camera.active)continue;
   boolean unique=camera.tags.optBoolean("unique",false);
   if("Unique".equals(typeFilter)&&!unique)continue;
   if(!"All".equals(typeFilter)&&!"Unique".equals(typeFilter)&&!typeFilter.equals(categoryFor(camera)))continue;
   Marker marker=new Marker(map);marker.setPosition(camera.point);marker.setAnchor(Marker.ANCHOR_CENTER,Marker.ANCHOR_BOTTOM);
   marker.setTitle((unique?"★ ":"")+camera.name);
   marker.setSubDescription(camera.kind+(camera.status.isEmpty()?"":" • "+camera.status));
   marker.setOnMarkerClickListener((clicked,view)->{showDetails(camera);return true;});
   map.getOverlays().add(marker);markers.add(marker);visible++;
   if("flocksurveillance.org".equals(camera.source))flockCount++;else if("openstreetmap".equals(camera.source))osmCount++;
  }
  map.invalidate();
  String attribution=flockCount>0?" Source: flocksurveillance.org map dataset.":"";
  if(osmCount>0)attribution+=" OSM records: © OpenStreetMap contributors, ODbL.";
  status.setText(lastLoadSummary+"\nShowing "+visible+" of "+cameras.size()+" saved records."+attribution);
 }

 void appendDetail(StringBuilder detail,String label,Object value){
  if(value==null)return;String text=String.valueOf(value).trim();
  if(text.isEmpty()||"null".equals(text)||"[]".equals(text))return;
  detail.append(label).append(": ").append(text).append("\n");
 }

 void showDetails(Camera camera){
  StringBuilder detail=new StringBuilder();
  appendDetail(detail,"Type",camera.kind);appendDetail(detail,"Status",camera.status);
  appendDetail(detail,"Active",camera.active?"yes":"no");appendDetail(detail,"Operator/source",camera.operator);
  appendDetail(detail,"Coordinates",camera.point.getLatitude()+", "+camera.point.getLongitude());
  if("flocksurveillance.org".equals(camera.source)){
   appendDetail(detail,"Features",camera.tags.opt("features"));appendDetail(detail,"Added",camera.tags.opt("creationDate"));
   appendDetail(detail,"Rotation",camera.tags.opt("rotationAngle"));appendDetail(detail,"Object ID",camera.tags.opt("objectId"));
   appendDetail(detail,"External ID",camera.tags.opt("externalId"));appendDetail(detail,"Network external ID",camera.tags.opt("networkExternalId"));
   appendDetail(detail,"Organization ID",camera.tags.opt("organizationId"));appendDetail(detail,"Network ID",camera.tags.opt("networkId"));
   appendDetail(detail,"Parent external ID",camera.tags.opt("parentExternalId"));
   if(camera.tags.optBoolean("unique",false)){
    detail.append("\nUnique Cameras review\n");
    appendDetail(detail,"Categories",camera.tags.opt("uniqueCategories"));appendDetail(detail,"Note",camera.tags.opt("uniqueNote"));
   }
   int coLocated=camera.tags.optInt("coLocatedCount",1);
   if(coLocated>1){
    appendDetail(detail,"Devices in nearby cluster",coLocated);appendDetail(detail,"Other labels",camera.tags.optJSONArray("coLocatedNames"));
    detail.append("Coordinate caution: dense clusters can use generalized or placeholder coordinates. Treat this point as a review lead, not proof of an exact device location.\n");
   }
  }else if("openstreetmap".equals(camera.source)){
   appendDetail(detail,"OSM feature",camera.osmType+"/"+camera.osmId);
   detail.append("\nOpenStreetMap tags\n");Iterator<String> keys=camera.tags.keys();
   while(keys.hasNext()){String key=keys.next();appendDetail(detail,key,camera.tags.opt(key));}
  }
  AlertDialog.Builder builder=new AlertDialog.Builder(this).setTitle(camera.name).setMessage(detail.toString()).setPositiveButton("Close",null);
  if(!camera.sourceUrl.isEmpty())builder.setNeutralButton("Open source",(dialog,which)->openUrl(camera.sourceUrl));
  builder.show();
 }
 void applyPendingMapTarget(){SharedPreferences target=getSharedPreferences("map_target",MODE_PRIVATE);if(!target.getBoolean("pending",false))return;try{double lat=Double.parseDouble(target.getString("latitude","0"));double lon=Double.parseDouble(target.getString("longitude","0"));map.getController().setCenter(new GeoPoint(lat,lon));map.getController().setZoom(16.0);status.setText("Showing the selected offline address result.");}catch(Exception e){status.setText("The saved address coordinates were invalid.");}finally{target.edit().putBoolean("pending",false).apply();}}
 @Override public void onResume(){super.onResume();if(map!=null){map.onResume();applyPendingMapTarget();}}
 @Override public void onPause(){if(map!=null)map.onPause();super.onPause();}
}
