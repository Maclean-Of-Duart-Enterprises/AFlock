package com.macleanofduartenterprises.aflock;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Handler;
import android.os.Looper;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.zip.GZIPInputStream;

/**
 * On-device address/place index. Searches never make a network request.
 * Detailed OSM records and the bundled worldwide place catalog share one FTS index.
 */
public final class AddressDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "offline-addresses.db";
    private static final int DATABASE_VERSION = 1;
    private static final String WORLD_INDEX_VERSION = "geonames-cities15000-2026-10";
    private static final AtomicBoolean WORLD_IMPORT_RUNNING = new AtomicBoolean(false);
    private static volatile AddressDatabase instance;

    private AddressDatabase(Context context) {
        super(context.getApplicationContext(), DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static AddressDatabase get(Context context) {
        if (instance == null) {
            synchronized (AddressDatabase.class) {
                if (instance == null) {
                    instance = new AddressDatabase(context);
                }
            }
        }
        return instance;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE places ("
                + "_id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "stable_id TEXT NOT NULL UNIQUE,"
                + "name TEXT NOT NULL,"
                + "display_address TEXT NOT NULL,"
                + "street TEXT NOT NULL DEFAULT '',"
                + "city TEXT NOT NULL DEFAULT '',"
                + "state TEXT NOT NULL DEFAULT '',"
                + "postcode TEXT NOT NULL DEFAULT '',"
                + "country TEXT NOT NULL DEFAULT '',"
                + "aliases TEXT NOT NULL DEFAULT '',"
                + "latitude REAL NOT NULL,"
                + "longitude REAL NOT NULL,"
                + "source TEXT NOT NULL,"
                + "pack_id TEXT NOT NULL,"
                + "updated_at INTEGER NOT NULL)"
        );
        db.execSQL("CREATE INDEX places_pack_index ON places(pack_id)");
        db.execSQL("CREATE INDEX places_coordinates_index ON places(latitude, longitude)");
        db.execSQL("CREATE VIRTUAL TABLE places_fts USING fts4("
                + "name, display_address, street, city, state, postcode, country, aliases,"
                + "tokenize=unicode61)"
        );
        db.execSQL("CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL)");
        db.execSQL("CREATE TABLE address_packs ("
                + "pack_id TEXT PRIMARY KEY,"
                + "label TEXT NOT NULL,"
                + "south REAL NOT NULL, west REAL NOT NULL, north REAL NOT NULL, east REAL NOT NULL,"
                + "record_count INTEGER NOT NULL, updated_at INTEGER NOT NULL)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS places_fts");
        db.execSQL("DROP TABLE IF EXISTS places");
        db.execSQL("DROP TABLE IF EXISTS metadata");
        db.execSQL("DROP TABLE IF EXISTS address_packs");
        onCreate(db);
    }

    public boolean isWorldIndexReady() {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor cursor = db.rawQuery("SELECT value FROM metadata WHERE key='world_index_version'", null)) {
            return cursor.moveToFirst() && WORLD_INDEX_VERSION.equals(cursor.getString(0));
        }
    }

    public void ensureWorldIndexAsync(Context context, ImportCallback callback) {
        Handler main = new Handler(Looper.getMainLooper());
        if (isWorldIndexReady()) {
            main.post(() -> callback.onComplete(countAll()));
            return;
        }
        if (!WORLD_IMPORT_RUNNING.compareAndSet(false, true)) {
            main.post(() -> callback.onProgress("Worldwide place index is already being prepared."));
            return;
        }
        Context appContext = context.getApplicationContext();
        new Thread(() -> {
            SQLiteDatabase db = getWritableDatabase();
            int imported = 0;
            try {
                db.beginTransaction();
                deletePackRows(db, "world_places");
                try (InputStream asset = appContext.getAssets().open("cities15000.dat");
                     GZIPInputStream gzip = new GZIPInputStream(asset, 64 * 1024);
                     BufferedReader reader = new BufferedReader(new InputStreamReader(gzip, StandardCharsets.UTF_8), 64 * 1024)) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        String[] fields = line.split("\\t", -1);
                        if (fields.length < 19) {
                            continue;
                        }
                        AddressEntry entry = new AddressEntry();
                        entry.stableId = "geonames:" + fields[0];
                        entry.name = firstNonEmpty(fields[1], fields[2], "Unnamed place");
                        entry.city = entry.name;
                        entry.state = fields[10];
                        entry.country = fields[8];
                        entry.postcode = "";
                        entry.street = "";
                        entry.aliases = truncate(fields[3] + " " + fields[2] + " " + fields[7], 4096);
                        entry.latitude = Double.parseDouble(fields[4]);
                        entry.longitude = Double.parseDouble(fields[5]);
                        entry.source = "GeoNames";
                        entry.packId = "world_places";
                        entry.updatedAt = System.currentTimeMillis();
                        entry.displayAddress = joinAddress(entry.name, entry.state, entry.country);
                        upsert(db, entry);
                        imported++;
                        if (imported % 2000 == 0) {
                            int progress = imported;
                            main.post(() -> callback.onProgress("Preparing worldwide offline place index: " + progress + " places"));
                        }
                    }
                }
                ContentValues metadata = new ContentValues();
                metadata.put("key", "world_index_version");
                metadata.put("value", WORLD_INDEX_VERSION);
                db.insertWithOnConflict("metadata", null, metadata, SQLiteDatabase.CONFLICT_REPLACE);
                db.setTransactionSuccessful();
                int finalImported = imported;
                main.post(() -> callback.onComplete(finalImported));
            } catch (Exception error) {
                main.post(() -> callback.onError("Could not prepare worldwide place index: " + safeMessage(error)));
            } finally {
                if (db.inTransaction()) {
                    db.endTransaction();
                }
                WORLD_IMPORT_RUNNING.set(false);
            }
        }, "AFlock-world-address-index").start();
    }

    public synchronized int replaceDetailedPack(
            String packId,
            String label,
            double south,
            double west,
            double north,
            double east,
            List<AddressEntry> entries
    ) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            deletePackRows(db, packId);
            for (AddressEntry entry : entries) {
                entry.packId = packId;
                upsert(db, entry);
            }
            ContentValues values = new ContentValues();
            values.put("pack_id", packId);
            values.put("label", label);
            values.put("south", south);
            values.put("west", west);
            values.put("north", north);
            values.put("east", east);
            values.put("record_count", entries.size());
            values.put("updated_at", System.currentTimeMillis());
            db.insertWithOnConflict("address_packs", null, values, SQLiteDatabase.CONFLICT_REPLACE);
            db.setTransactionSuccessful();
            return entries.size();
        } finally {
            db.endTransaction();
        }
    }

    public List<AddressResult> search(String query, int limit) {
        String ftsQuery = AddressQuery.toFtsPrefixQuery(query);
        if (ftsQuery.isEmpty()) {
            return new ArrayList<>();
        }
        int safeLimit = Math.max(1, Math.min(200, limit));
        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT p.name,p.display_address,p.latitude,p.longitude,p.source "
                + "FROM places_fts f JOIN places p ON p._id=f.docid "
                + "WHERE places_fts MATCH ? LIMIT " + safeLimit;
        try (Cursor cursor = db.rawQuery(sql, new String[]{ftsQuery})) {
            return readResults(cursor);
        } catch (SQLiteException unsupportedFtsQuery) {
            String like = "%" + query.trim() + "%";
            String fallback = "SELECT name,display_address,latitude,longitude,source FROM places "
                    + "WHERE name LIKE ? OR display_address LIKE ? OR aliases LIKE ? LIMIT " + safeLimit;
            try (Cursor cursor = db.rawQuery(fallback, new String[]{like, like, like})) {
                return readResults(cursor);
            }
        }
    }

    public int countAll() {
        try (Cursor cursor = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM places", null)) {
            return cursor.moveToFirst() ? cursor.getInt(0) : 0;
        }
    }

    public int detailedPackCount() {
        try (Cursor cursor = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM address_packs", null)) {
            return cursor.moveToFirst() ? cursor.getInt(0) : 0;
        }
    }

    private static List<AddressResult> readResults(Cursor cursor) {
        List<AddressResult> results = new ArrayList<>();
        while (cursor.moveToNext()) {
            AddressResult result = new AddressResult();
            result.name = cursor.getString(0);
            result.displayAddress = cursor.getString(1);
            result.latitude = cursor.getDouble(2);
            result.longitude = cursor.getDouble(3);
            result.source = cursor.getString(4);
            results.add(result);
        }
        return results;
    }

    private static void deletePackRows(SQLiteDatabase db, String packId) {
        List<Long> ids = new ArrayList<>();
        try (Cursor cursor = db.rawQuery("SELECT _id FROM places WHERE pack_id=?", new String[]{packId})) {
            while (cursor.moveToNext()) {
                ids.add(cursor.getLong(0));
            }
        }
        for (Long id : ids) {
            db.delete("places_fts", "docid=?", new String[]{String.valueOf(id)});
        }
        db.delete("places", "pack_id=?", new String[]{packId});
    }

    private static void upsert(SQLiteDatabase db, AddressEntry entry) {
        Long existingId = null;
        try (Cursor cursor = db.rawQuery("SELECT _id FROM places WHERE stable_id=?", new String[]{entry.stableId})) {
            if (cursor.moveToFirst()) {
                existingId = cursor.getLong(0);
            }
        }

        ContentValues values = new ContentValues();
        values.put("stable_id", entry.stableId);
        values.put("name", nonNull(entry.name));
        values.put("display_address", nonNull(entry.displayAddress));
        values.put("street", nonNull(entry.street));
        values.put("city", nonNull(entry.city));
        values.put("state", nonNull(entry.state));
        values.put("postcode", nonNull(entry.postcode));
        values.put("country", nonNull(entry.country));
        values.put("aliases", nonNull(entry.aliases));
        values.put("latitude", entry.latitude);
        values.put("longitude", entry.longitude);
        values.put("source", nonNull(entry.source));
        values.put("pack_id", nonNull(entry.packId));
        values.put("updated_at", entry.updatedAt);

        long rowId;
        if (existingId == null) {
            rowId = db.insertOrThrow("places", null, values);
        } else {
            rowId = existingId;
            db.update("places", values, "_id=?", new String[]{String.valueOf(rowId)});
            db.delete("places_fts", "docid=?", new String[]{String.valueOf(rowId)});
        }

        db.execSQL(
                "INSERT INTO places_fts(docid,name,display_address,street,city,state,postcode,country,aliases) "
                        + "VALUES(?,?,?,?,?,?,?,?,?)",
                new Object[]{
                        rowId,
                        nonNull(entry.name),
                        nonNull(entry.displayAddress),
                        nonNull(entry.street),
                        nonNull(entry.city),
                        nonNull(entry.state),
                        nonNull(entry.postcode),
                        nonNull(entry.country),
                        nonNull(entry.aliases)
                }
        );
    }

    private static String joinAddress(String... pieces) {
        StringBuilder value = new StringBuilder();
        for (String piece : pieces) {
            if (piece != null && !piece.trim().isEmpty()) {
                if (value.length() > 0) {
                    value.append(", ");
                }
                value.append(piece.trim());
            }
        }
        return value.toString();
    }

    private static String firstNonEmpty(String... choices) {
        for (String choice : choices) {
            if (choice != null && !choice.trim().isEmpty()) {
                return choice.trim();
            }
        }
        return "";
    }

    private static String truncate(String value, int maximumLength) {
        if (value == null) {
            return "";
        }
        return value.length() <= maximumLength ? value : value.substring(0, maximumLength);
    }

    private static String nonNull(String value) {
        return value == null ? "" : value;
    }

    private static String safeMessage(Throwable error) {
        String message = error.getMessage();
        return message == null || message.trim().isEmpty() ? error.getClass().getSimpleName() : message;
    }

    public interface ImportCallback {
        void onProgress(String message);

        void onComplete(int recordCount);

        void onError(String message);
    }

    public static final class AddressEntry {
        public String stableId = "";
        public String name = "";
        public String displayAddress = "";
        public String street = "";
        public String city = "";
        public String state = "";
        public String postcode = "";
        public String country = "";
        public String aliases = "";
        public double latitude;
        public double longitude;
        public String source = "";
        public String packId = "";
        public long updatedAt = System.currentTimeMillis();
    }

    public static final class AddressResult {
        public String name;
        public String displayAddress;
        public double latitude;
        public double longitude;
        public String source;

        @Override
        public String toString() {
            return String.format(Locale.getDefault(), "%s\n%s", name, displayAddress);
        }
    }
}
