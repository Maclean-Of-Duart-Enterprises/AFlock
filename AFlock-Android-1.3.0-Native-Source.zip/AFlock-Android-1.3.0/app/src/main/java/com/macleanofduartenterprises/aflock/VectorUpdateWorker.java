package com.macleanofduartenterprises.aflock;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/** Weekly unmetered cache revalidation for downloaded MapLibre regions. */
public final class VectorUpdateWorker extends Worker {
    public static final String UNIQUE_WORK_NAME = "aflock-vector-map-updates";

    public VectorUpdateWorker(@NonNull Context context, @NonNull WorkerParameters parameters) {
        super(context, parameters);
    }

    @NonNull
    @Override
    public Result doWork() {
        CountDownLatch completed = new CountDownLatch(1);
        AtomicInteger failures = new AtomicInteger();
        new Handler(Looper.getMainLooper()).post(() -> VectorMapUpdater.updateAll(
                getApplicationContext(),
                new VectorMapUpdater.Callback() {
                    @Override
                    public void onProgress(String message) {
                        // WorkManager exposes final status; live UI progress is unnecessary here.
                    }

                    @Override
                    public void onFinished(int queued, int errors, String message) {
                        failures.set(errors);
                        completed.countDown();
                    }
                }
        ));
        try {
            if (!completed.await(4, TimeUnit.MINUTES)) {
                return Result.retry();
            }
            return failures.get() == 0 ? Result.success() : Result.retry();
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            return Result.retry();
        }
    }

    public static void schedule(Context context) {
        Constraints constraints = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.UNMETERED)
                .setRequiresBatteryNotLow(true)
                .build();
        PeriodicWorkRequest request = new PeriodicWorkRequest.Builder(
                VectorUpdateWorker.class,
                7,
                TimeUnit.DAYS
        ).setConstraints(constraints).build();
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                UNIQUE_WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                request
        );
    }
}
