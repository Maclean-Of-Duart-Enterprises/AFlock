package com.macleanofduartenterprises.aflock;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.StatFs;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.maplibre.android.MapLibre;
import org.maplibre.android.camera.CameraPosition;
import org.maplibre.android.geometry.LatLng;
import org.maplibre.android.geometry.LatLngBounds;
import org.maplibre.android.maps.MapLibreMap;
import org.maplibre.android.maps.MapView;
import org.maplibre.android.net.ConnectivityReceiver;
import org.maplibre.android.offline.OfflineManager;
import org.maplibre.android.offline.OfflineRegion;
import org.maplibre.android.offline.OfflineRegionDefinition;
import org.maplibre.android.offline.OfflineRegionError;
import org.maplibre.android.offline.OfflineRegionStatus;
import org.maplibre.android.offline.OfflineTilePyramidRegionDefinition;

import java.util.Locale;

/** MapLibre view, worldwide catalog, offline address packs, and vector cache updates. */
public final class VectorMapActivity extends ThemedActivity {
    private static final String BUILT_IN_WORLD_STYLE = "asset://world_style.json";

    private MapView map;
    private MapLibreMap controller;
    private TextView status;
    private SharedPreferences preferences;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        MapLibre.getInstance(this);
        preferences = getSharedPreferences("vector_map", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        LinearLayout firstRow = new LinearLayout(this);
        Button style = button("Map style");
        Button world = button("Worldwide offline atlas");
        Button offline = button(preferences.getBoolean("offline", false) ? "Go online" : "Strict offline");
        firstRow.addView(style, weighted());
        firstRow.addView(world, weighted());
        firstRow.addView(offline, weighted());
        root.addView(firstRow);

        LinearLayout secondRow = new LinearLayout(this);
        Button download = button("Save visible region");
        Button manage = button("Manage regions");
        Button update = button("Update regions");
        secondRow.addView(download, weighted());
        secondRow.addView(manage, weighted());
        secondRow.addView(update, weighted());
        root.addView(secondRow);

        LinearLayout thirdRow = new LinearLayout(this);
        Button addresses = button("Offline address search");
        Button coverage = button("Coverage at center");
        Button schedule = button("Weekly updates");
        thirdRow.addView(addresses, weighted());
        thirdRow.addView(coverage, weighted());
        thirdRow.addView(schedule, weighted());
        root.addView(thirdRow);

        status = new TextView(this);
        status.setPadding(14, 8, 14, 8);
        status.setText("The built-in worldwide overview works without a network. Configure an offline-permitted vector style for street-level downloads.");
        root.addView(status);

        map = new MapView(this);
        map.onCreate(state);
        root.addView(map, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1
        ));
        setContentView(root);

        map.getMapAsync(mapController -> {
            controller = mapController;
            controller.setMinZoomPreference(0.0);
            controller.setMaxZoomPreference(20.0);
            controller.setStyle(activeStyle());
            applyConnectivityMode();
            applyPendingMapTarget();
        });

        style.setOnClickListener(view -> promptForStyle());
        world.setOnClickListener(view -> startActivity(new Intent(this, WorldOfflineActivity.class)));
        offline.setOnClickListener(view -> {
            boolean enabled = !preferences.getBoolean("offline", false);
            preferences.edit().putBoolean("offline", enabled).apply();
            applyConnectivityMode();
            offline.setText(enabled ? "Go online" : "Strict offline");
            status.setText(enabled
                    ? "Strict offline mode enabled. MapLibre network requests are disabled."
                    : "Online resource requests enabled.");
        });
        download.setOnClickListener(view -> downloadVisibleRegion());
        manage.setOnClickListener(view -> manageRegions());
        update.setOnClickListener(view -> updateAllRegions());
        addresses.setOnClickListener(view -> openAddressSearch());
        coverage.setOnClickListener(view -> checkCoverage());
        schedule.setOnClickListener(view -> {
            VectorUpdateWorker.schedule(this);
            status.setText("Weekly incremental vector-map updates scheduled for unmetered networks when battery is not low.");
        });
    }

    private Button button(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        return button;
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
    }

    private String activeStyle() {
        String saved = preferences.getString("style", "").trim();
        return saved.startsWith("https://") ? saved : BUILT_IN_WORLD_STYLE;
    }

    private void promptForStyle() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("https://provider.example/style.json");
        input.setText(preferences.getString("style", ""));
        new AlertDialog.Builder(this)
                .setTitle("Detailed vector-map style")
                .setMessage("Enter an HTTPS MapLibre style whose provider permits offline downloads. "
                        + "The built-in Natural Earth overview remains available without a provider.")
                .setView(input)
                .setNegativeButton("Cancel", null)
                .setNeutralButton("Use built-in overview", (dialog, which) -> {
                    preferences.edit().remove("style").apply();
                    if (controller != null) {
                        controller.setStyle(BUILT_IN_WORLD_STYLE);
                    }
                    status.setText("Using the bundled worldwide overview. No network is needed.");
                })
                .setPositiveButton("Save and apply", (dialog, which) -> {
                    String value = input.getText().toString().trim();
                    if (!value.startsWith("https://")) {
                        status.setText("A valid HTTPS style URL is required.");
                        return;
                    }
                    preferences.edit().putString("style", value).apply();
                    if (controller != null) {
                        controller.setStyle(value);
                    }
                    status.setText("Detailed vector style applied. Provider terms still control offline downloads.");
                })
                .show();
    }

    private void downloadVisibleRegion() {
        if (controller == null || controller.getStyle() == null) {
            status.setText("Map is not ready yet.");
            return;
        }
        String styleUrl = preferences.getString("style", "").trim();
        if (!styleUrl.startsWith("https://")) {
            status.setText("Configure an HTTPS detailed-map style before saving a detailed region.");
            promptForStyle();
            return;
        }
        if (preferences.getBoolean("offline", false)) {
            status.setText("Disable strict offline mode before starting a download.");
            return;
        }
        long available = new StatFs(getFilesDir().getAbsolutePath()).getAvailableBytes();
        if (available < 512L * 1024L * 1024L) {
            status.setText("At least 512 MiB free storage is required before starting.");
            return;
        }
        LatLngBounds bounds = controller.getProjection().getVisibleRegion().latLngBounds;
        OfflineTilePyramidRegionDefinition definition = new OfflineTilePyramidRegionDefinition(
                styleUrl,
                bounds,
                Math.max(0.0, controller.getCameraPosition().zoom - 2.0),
                14.0,
                getResources().getDisplayMetrics().density
        );
        String stableId = "visible_" + System.currentTimeMillis();
        OfflineRegionMetadata metadata = OfflineRegionMetadata.create(
                "visible-region",
                stableId,
                "Visible region " + new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new java.util.Date()),
                styleUrl
        );
        status.setText("Creating offline vector region…");
        OfflineManager.getInstance(this).createOfflineRegion(
                definition,
                metadata.toBytes(),
                new OfflineManager.CreateOfflineRegionCallback() {
                    @Override
                    public void onCreate(OfflineRegion region) {
                        observeDownload(region, metadata.name);
                        region.setDownloadState(OfflineRegion.STATE_ACTIVE);
                    }

                    @Override
                    public void onError(String error) {
                        status.setText("Cannot create region: " + error);
                    }
                }
        );
    }

    private void observeDownload(OfflineRegion region, String name) {
        region.setObserver(new OfflineRegion.OfflineRegionObserver() {
            @Override
            public void onStatusChanged(OfflineRegionStatus downloadStatus) {
                if (downloadStatus == null) {
                    return;
                }
                long complete = downloadStatus.getCompletedResourceCount();
                long required = downloadStatus.getRequiredResourceCount();
                String progress = required > 0 && downloadStatus.isRequiredResourceCountPrecise()
                        ? String.format(Locale.getDefault(), "%.1f%%", 100.0 * complete / required)
                        : complete + " resources";
                status.setText(name + ": " + progress + " · "
                        + downloadStatus.getCompletedResourceSize() / 1_048_576L + " MiB");
                if (downloadStatus.isComplete()) {
                    region.setDownloadState(OfflineRegion.STATE_INACTIVE);
                    status.setText(name + " is complete and available offline.");
                }
            }

            @Override
            public void onError(OfflineRegionError error) {
                status.setText("Offline vector error: " + error.getMessage());
            }

            @Override
            public void mapboxTileCountLimitExceeded(long limit) {
                region.setDownloadState(OfflineRegion.STATE_INACTIVE);
                status.setText("Provider tile limit reached: " + limit);
            }
        });
    }

    private void manageRegions() {
        OfflineManager.getInstance(this).listOfflineRegions(new OfflineManager.ListOfflineRegionsCallback() {
            @Override
            public void onList(OfflineRegion[] regions) {
                if (regions == null || regions.length == 0) {
                    status.setText("No detailed vector regions are stored. The bundled overview remains available.");
                    return;
                }
                String[] names = new String[regions.length];
                for (int index = 0; index < regions.length; index++) {
                    OfflineRegionMetadata metadata = OfflineRegionMetadata.parse(regions[index].getMetadata());
                    names[index] = metadata.name + " (region " + regions[index].getId() + ")";
                }
                new AlertDialog.Builder(VectorMapActivity.this)
                        .setTitle("Saved vector regions")
                        .setItems(names, (dialog, index) -> showRegionActions(regions[index], names[index]))
                        .setNegativeButton("Close", null)
                        .show();
            }

            @Override
            public void onError(String error) {
                status.setText("Cannot list offline regions: " + error);
            }
        });
    }

    private void showRegionActions(OfflineRegion region, String name) {
        new AlertDialog.Builder(this)
                .setTitle(name)
                .setMessage("Update uses cache revalidation so unchanged vector resources are retained.")
                .setNegativeButton("Close", null)
                .setNeutralButton("Delete", (dialog, which) -> region.delete(new OfflineRegion.OfflineRegionDeleteCallback() {
                    @Override
                    public void onDelete() {
                        status.setText("Offline region deleted.");
                    }

                    @Override
                    public void onError(String error) {
                        status.setText("Delete error: " + error);
                    }
                }))
                .setPositiveButton("Incremental update", (dialog, which) -> updateOne(region, name))
                .show();
    }

    private void updateOne(OfflineRegion region, String name) {
        if (preferences.getBoolean("offline", false)) {
            status.setText("Disable strict offline mode before requesting an update.");
            return;
        }
        status.setText("Revalidating " + name + "…");
        region.invalidate(new OfflineRegion.OfflineRegionInvalidateCallback() {
            @Override
            public void onInvalidate() {
                OfflineRegionMetadata updated = OfflineRegionMetadata.parse(region.getMetadata()).withUpdateRequestedNow();
                region.updateMetadata(updated.toBytes(), new OfflineRegion.OfflineRegionUpdateMetadataCallback() {
                    @Override
                    public void onUpdate(byte[] bytes) {
                    }

                    @Override
                    public void onError(String error) {
                    }
                });
                observeDownload(region, name);
                region.setDownloadState(OfflineRegion.STATE_ACTIVE);
            }

            @Override
            public void onError(String error) {
                status.setText("Update could not start: " + error);
            }
        });
    }

    private void updateAllRegions() {
        status.setText("Preparing incremental updates…");
        VectorMapUpdater.updateAll(this, new VectorMapUpdater.Callback() {
            @Override
            public void onProgress(String message) {
                status.setText(message);
            }

            @Override
            public void onFinished(int queued, int errors, String message) {
                status.setText(message);
            }
        });
    }

    private void checkCoverage() {
        if (controller == null) {
            status.setText("Map is not ready yet.");
            return;
        }
        LatLng center = controller.getCameraPosition().target;
        OfflineManager.getInstance(this).listOfflineRegions(new OfflineManager.ListOfflineRegionsCallback() {
            @Override
            public void onList(OfflineRegion[] regions) {
                int matches = 0;
                if (regions != null) {
                    for (OfflineRegion region : regions) {
                        OfflineRegionDefinition definition = region.getDefinition();
                        if (definition instanceof OfflineTilePyramidRegionDefinition) {
                            LatLngBounds bounds = ((OfflineTilePyramidRegionDefinition) definition).getBounds();
                            if (bounds.contains(center)) {
                                matches++;
                            }
                        }
                    }
                }
                status.setText(matches + " downloaded region(s) contain the map center. "
                        + "The bundled low-detail worldwide overview is always available.");
            }

            @Override
            public void onError(String error) {
                status.setText("Coverage check failed: " + error);
            }
        });
    }

    private void openAddressSearch() {
        Intent intent = new Intent(this, OfflineAddressSearchActivity.class);
        if (controller != null) {
            LatLngBounds bounds = controller.getProjection().getVisibleRegion().latLngBounds;
            intent.putExtra("south", bounds.getLatSouth());
            intent.putExtra("west", bounds.getLonWest());
            intent.putExtra("north", bounds.getLatNorth());
            intent.putExtra("east", bounds.getLonEast());
        }
        startActivity(intent);
    }

    private void applyConnectivityMode() {
        boolean offline = preferences.getBoolean("offline", false);
        ConnectivityReceiver.instance(this).setConnected(!offline);
    }

    private void applyPendingMapTarget() {
        if (controller == null) {
            return;
        }
        SharedPreferences target = getSharedPreferences("map_target", MODE_PRIVATE);
        if (!target.getBoolean("pending", false)) {
            return;
        }
        try {
            double latitude = Double.parseDouble(target.getString("latitude", "0"));
            double longitude = Double.parseDouble(target.getString("longitude", "0"));
            controller.setCameraPosition(new CameraPosition.Builder()
                    .target(new LatLng(latitude, longitude))
                    .zoom(15.0)
                    .build());
            status.setText("Showing the selected offline address result.");
        } catch (NumberFormatException error) {
            status.setText("The saved address coordinates were invalid.");
        } finally {
            target.edit().putBoolean("pending", false).apply();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (map != null) {
            map.onStart();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (map != null) {
            map.onResume();
        }
        applyConnectivityMode();
        applyPendingMapTarget();
    }

    @Override
    protected void onPause() {
        if (map != null) {
            map.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onStop() {
        if (map != null) {
            map.onStop();
        }
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        if (map != null) {
            map.onDestroy();
        }
        super.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        if (map != null) {
            map.onLowMemory();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (map != null) {
            map.onSaveInstanceState(outState);
        }
    }
}
