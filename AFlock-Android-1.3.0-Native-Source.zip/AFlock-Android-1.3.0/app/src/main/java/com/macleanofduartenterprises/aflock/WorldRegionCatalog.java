package com.macleanofduartenterprises.aflock;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Stable, provider-neutral coverage grid for detailed offline vector regions.
 * The grid covers every coordinate supported by Web Mercator.
 */
public final class WorldRegionCatalog {
    public static final double MERCATOR_MAX_LATITUDE = 85.05112878;
    private static final double[] LATITUDE_EDGES = {
            MERCATOR_MAX_LATITUDE,
            56.70075252,
            28.35037626,
            0.0,
            -28.35037626,
            -56.70075252,
            -MERCATOR_MAX_LATITUDE
    };

    private WorldRegionCatalog() {
    }

    public static WorldRegion worldOverview() {
        return new WorldRegion(
                "world_overview",
                "Worldwide overview (low detail)",
                -MERCATOR_MAX_LATITUDE,
                -180.0,
                MERCATOR_MAX_LATITUDE,
                180.0,
                0,
                5
        );
    }

    public static List<WorldRegion> detailedRegions(int maximumZoom) {
        int safeMaximumZoom = Math.max(8, Math.min(14, maximumZoom));
        List<WorldRegion> result = new ArrayList<>();
        for (int latitudeBand = 0; latitudeBand < LATITUDE_EDGES.length - 1; latitudeBand++) {
            double north = LATITUDE_EDGES[latitudeBand];
            double south = LATITUDE_EDGES[latitudeBand + 1];
            for (int longitudeBand = 0; longitudeBand < 12; longitudeBand++) {
                double west = -180.0 + longitudeBand * 30.0;
                double east = west + 30.0;
                String id = String.format(Locale.US, "world_b%02d_c%02d", latitudeBand, longitudeBand);
                String name = String.format(
                        Locale.US,
                        "Zone %s · %.1f° to %.1f° latitude, %.0f° to %.0f° longitude",
                        id.substring("world_".length()).toUpperCase(Locale.US),
                        south,
                        north,
                        west,
                        east
                );
                result.add(new WorldRegion(id, name, south, west, north, east, 6, safeMaximumZoom));
            }
        }
        return Collections.unmodifiableList(result);
    }

    public static WorldRegion findRegion(double latitude, double longitude, int maximumZoom) {
        double safeLatitude = Math.max(-MERCATOR_MAX_LATITUDE, Math.min(MERCATOR_MAX_LATITUDE, latitude));
        double safeLongitude = longitude;
        while (safeLongitude < -180.0) {
            safeLongitude += 360.0;
        }
        while (safeLongitude > 180.0) {
            safeLongitude -= 360.0;
        }
        if (safeLongitude == 180.0) {
            safeLongitude = Math.nextDown(180.0);
        }

        for (WorldRegion region : detailedRegions(maximumZoom)) {
            if (safeLatitude >= region.south && safeLatitude <= region.north
                    && safeLongitude >= region.west && safeLongitude < region.east) {
                return region;
            }
        }
        throw new IllegalStateException("Worldwide region catalog has a coverage gap");
    }

    public static final class WorldRegion {
        public final String id;
        public final String name;
        public final double south;
        public final double west;
        public final double north;
        public final double east;
        public final double minimumZoom;
        public final double maximumZoom;

        public WorldRegion(
                String id,
                String name,
                double south,
                double west,
                double north,
                double east,
                double minimumZoom,
                double maximumZoom
        ) {
            this.id = id;
            this.name = name;
            this.south = south;
            this.west = west;
            this.north = north;
            this.east = east;
            this.minimumZoom = minimumZoom;
            this.maximumZoom = maximumZoom;
        }
    }
}
