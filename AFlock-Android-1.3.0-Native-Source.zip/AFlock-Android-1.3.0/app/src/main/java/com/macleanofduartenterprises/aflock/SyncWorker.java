package com.macleanofduartenterprises.aflock;
import android.content.*;
import androidx.annotation.NonNull;
import androidx.work.*;
import org.json.*;
/** Periodically snapshots surveillance features around the last selected map center. */
public class SyncWorker extends Worker {
 public SyncWorker(@NonNull Context c,@NonNull WorkerParameters p){super(c,p);}
 @NonNull @Override public Result doWork(){Context ctx=getApplicationContext();float lat=ctx.getSharedPreferences("sync",0).getFloat("lat",40.34f),lon=ctx.getSharedPreferences("sync",0).getFloat("lon",-76.42f);
  double latitudeDelta=0.1d;double cosine=Math.max(0.2d,Math.cos(Math.toRadians(lat)));double longitudeDelta=0.1d/cosine;
  FlockSurveillanceClient.Bounds bounds=new FlockSurveillanceClient.Bounds(
          lat-latitudeDelta,lon-longitudeDelta,lat+latitudeDelta,lon+longitudeDelta);
  try {
   FlockSurveillanceClient.Result cameras=FlockSurveillanceClient.loadVisible(ctx,bounds,false,null);
   JSONArray normalized=new JSONArray();for(FlockSurveillanceClient.Device device:cameras.devices)normalized.put(device.toNormalizedRecord());
   RecordStore.mergeNormalized(ctx,normalized);return Result.success();
  }catch(Exception primaryError){
   String query="[out:json][timeout:25];(node[man_made=surveillance](around:10000,"+lat+","+lon+");way[man_made=surveillance](around:10000,"+lat+","+lon+"););out center 2000;";
   try {OverpassClient.Response response=OverpassClient.execute(query,15000,35000,10000000,null);
    JSONObject data=new JSONObject(new String(response.getBody(),"UTF-8"));if(!data.has("elements"))return Result.retry();RecordStore.merge(ctx,data.getJSONArray("elements"));return Result.success();
   }catch(Exception fallbackError){return Result.retry();}
  }
 }
}
