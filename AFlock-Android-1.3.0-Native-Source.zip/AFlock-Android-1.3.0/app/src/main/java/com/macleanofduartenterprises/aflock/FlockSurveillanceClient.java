package com.macleanofduartenterprises.aflock;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Downloads and parses the public dataset used by flocksurveillance.org.
 *
 * <p>The large TSV is cached on-device and filtered while it is streamed from disk, so the map
 * only retains records inside the requested viewport. The Unique Cameras page is downloaded as
 * inert text and parsed for its curated names/coordinates; no site JavaScript is executed.</p>
 */
final class FlockSurveillanceClient {
    static final String MAP_URL = "https://flocksurveillance.org/index.html";
    static final String UNIQUE_URL = "https://flocksurveillance.org/unique.html";
    static final String DATA_URL = "https://flocksurveillance.org/data/cameras.tsv";

    private static final String DATA_CACHE = "flocksurveillance-cameras.tsv";
    private static final String UNIQUE_CACHE = "flocksurveillance-unique.html";
    private static final String PREFERENCES = "flock_source";
    private static final long CACHE_FRESH_MILLIS = 6L * 60L * 60L * 1000L;
    private static final long MAX_DATA_BYTES = 100L * 1024L * 1024L;
    private static final long MAX_UNIQUE_BYTES = 2L * 1024L * 1024L;
    private static final double UNIQUE_COORDINATE_TOLERANCE = 0.00016d;
    private static final Object CACHE_LOCK = new Object();
    private static final String USER_AGENT =
            "AFlock/1.3.0 (contact: office@macleanofduartenterprises.com)";

    interface ProgressListener {
        void onProgress(String message);
    }

    static final class Bounds {
        final double south;
        final double west;
        final double north;
        final double east;

        Bounds(double south, double west, double north, double east) {
            this.south = Math.min(south, north);
            this.west = west;
            this.north = Math.max(south, north);
            this.east = east;
        }

        boolean contains(double latitude, double longitude) {
            if (latitude < south || latitude > north) {
                return false;
            }
            if (west <= east) {
                return longitude >= west && longitude <= east;
            }
            return longitude >= west || longitude <= east;
        }
    }

    static final class Device {
        double latitude;
        double longitude;
        String rawLatitude = "";
        String rawLongitude = "";
        String type = "";
        String status = "";
        boolean active;
        String name = "";
        String features = "";
        String rotationAngle = "";
        String objectId = "";
        String externalId = "";
        String networkExternalId = "";
        String organizationId = "";
        String networkId = "";
        String creationDate = "";
        String parentExternalId = "";
        boolean unique;
        String uniqueCategories = "";
        String uniqueNote = "";
        int coLocatedCount = 1;
        final ArrayList<String> coLocatedNames = new ArrayList<>();

        String stableId() {
            if (!objectId.isEmpty()) {
                return objectId;
            }
            if (!externalId.isEmpty()) {
                return "external:" + externalId;
            }
            if (!networkExternalId.isEmpty()) {
                return "network-external:" + networkExternalId;
            }
            return rawLatitude + ":" + rawLongitude + ":" + name;
        }

        String coordinateKey() {
            return rawLatitude + ":" + rawLongitude;
        }

        JSONObject toNormalizedRecord() throws JSONException {
            JSONObject tags = new JSONObject();
            tags.put("source", "flocksurveillance.org");
            tags.put("sourceType", type);
            tags.put("status", status);
            tags.put("active", active);
            tags.put("features", features);
            tags.put("rotationAngle", rotationAngle);
            tags.put("objectId", objectId);
            tags.put("externalId", externalId);
            tags.put("networkExternalId", networkExternalId);
            tags.put("organizationId", organizationId);
            tags.put("networkId", networkId);
            tags.put("creationDate", creationDate);
            tags.put("parentExternalId", parentExternalId);
            tags.put("unique", unique);
            tags.put("uniqueCategories", uniqueCategories);
            tags.put("uniqueNote", uniqueNote);
            tags.put("coLocatedCount", coLocatedCount);
            JSONArray neighbors = new JSONArray();
            for (String neighbor : coLocatedNames) {
                neighbors.put(neighbor);
            }
            tags.put("coLocatedNames", neighbors);

            JSONObject record = new JSONObject();
            record.put("lat", latitude);
            record.put("lon", longitude);
            record.put("name", name.isEmpty() ? "Unnamed Flock device" : name);
            record.put("kind", humanType(type));
            record.put("operator", "Flock Surveillance dataset");
            record.put("status", status);
            record.put("active", active);
            record.put("disused", "decommissioned".equalsIgnoreCase(status));
            record.put("source", "flocksurveillance.org");
            record.put("sourceId", stableId());
            record.put("sourceUrl", sourceUrl(objectId, latitude, longitude));
            record.put("osmType", "");
            record.put("osmId", 0L);
            record.put("tags", tags);
            return record;
        }
    }

    static final class Result {
        final List<Device> devices;
        final int scannedRecords;
        final int uniqueRecords;
        final boolean refreshedDataset;
        final boolean usedStaleDataset;
        final String warning;

        Result(
                List<Device> devices,
                int scannedRecords,
                int uniqueRecords,
                boolean refreshedDataset,
                boolean usedStaleDataset,
                String warning
        ) {
            this.devices = devices;
            this.scannedRecords = scannedRecords;
            this.uniqueRecords = uniqueRecords;
            this.refreshedDataset = refreshedDataset;
            this.usedStaleDataset = usedStaleDataset;
            this.warning = warning;
        }
    }

    static final class UniqueEntry {
        final String objectId;
        final String title;
        final double latitude;
        final double longitude;
        final String categories;
        final String note;

        UniqueEntry(
                String objectId,
                String title,
                double latitude,
                double longitude,
                String categories,
                String note
        ) {
            this.objectId = objectId;
            this.title = title;
            this.latitude = latitude;
            this.longitude = longitude;
            this.categories = categories;
            this.note = note;
        }
    }

    static final class UniqueCatalog {
        private final ArrayList<UniqueEntry> entries = new ArrayList<>();
        private final HashMap<String, UniqueEntry> byObjectId = new HashMap<>();
        private final HashMap<String, UniqueEntry> byName = new HashMap<>();

        void add(UniqueEntry entry) {
            String dedupeKey = entry.objectId + "|" + entry.title.toLowerCase(Locale.ROOT)
                    + "|" + entry.latitude + "|" + entry.longitude;
            for (UniqueEntry existing : entries) {
                String existingKey = existing.objectId + "|"
                        + existing.title.toLowerCase(Locale.ROOT) + "|"
                        + existing.latitude + "|" + existing.longitude;
                if (existingKey.equals(dedupeKey)) {
                    return;
                }
            }
            entries.add(entry);
            if (!entry.objectId.isEmpty()) {
                byObjectId.put(entry.objectId, entry);
            }
            if (!entry.title.isEmpty()) {
                byName.put(entry.title.trim().toLowerCase(Locale.ROOT), entry);
            }
        }

        int size() {
            return entries.size();
        }

        UniqueEntry match(Device device) {
            UniqueEntry match = byObjectId.get(device.objectId);
            if (match == null) {
                match = byName.get(device.name.trim().toLowerCase(Locale.ROOT));
            }
            if (match != null) {
                return match;
            }
            for (UniqueEntry entry : entries) {
                double latitudeDelta = device.latitude - entry.latitude;
                double longitudeDelta = device.longitude - entry.longitude;
                if (Math.hypot(latitudeDelta, longitudeDelta) <= UNIQUE_COORDINATE_TOLERANCE
                        && namesOverlap(device.name, entry.title)) {
                    return entry;
                }
            }
            return null;
        }

        private static boolean namesOverlap(String first, String second) {
            String a = first == null ? "" : first.trim().toLowerCase(Locale.ROOT);
            String b = second == null ? "" : second.trim().toLowerCase(Locale.ROOT);
            return !a.isEmpty() && !b.isEmpty()
                    && (a.equals(b) || (a.length() >= 12 && b.contains(a))
                    || (b.length() >= 12 && a.contains(b)));
        }
    }

    private static final class ParsedDevices {
        final List<Device> devices;
        final int scanned;
        final int unique;

        ParsedDevices(List<Device> devices, int scanned, int unique) {
            this.devices = devices;
            this.scanned = scanned;
            this.unique = unique;
        }
    }

    private FlockSurveillanceClient() {
    }

    static Result loadVisible(
            Context context,
            Bounds bounds,
            boolean forceRefresh,
            ProgressListener progress
    ) throws IOException {
        synchronized (CACHE_LOCK) {
            File dataset = new File(context.getFilesDir(), DATA_CACHE);
            File uniquePage = new File(context.getFilesDir(), UNIQUE_CACHE);
            boolean refreshed = false;
            boolean stale = false;
            String warning = "";

            if (forceRefresh || !validDatasetCache(dataset) || !isFresh(dataset)) {
                try {
                    notifyProgress(progress, "Checking the Flock Surveillance camera dataset…");
                    refreshed = downloadToCache(
                            context,
                            DATA_URL,
                            dataset,
                            MAX_DATA_BYTES,
                            "dataset",
                            true,
                            progress
                    );
                } catch (IOException error) {
                    if (!validDatasetCache(dataset)) {
                        throw error;
                    }
                    stale = true;
                    warning = "Live dataset refresh failed; using the saved Flock Surveillance dataset.";
                    notifyProgress(progress, warning);
                }
            }

            if (forceRefresh || !uniquePage.isFile() || !isFresh(uniquePage)) {
                try {
                    downloadToCache(
                            context,
                            UNIQUE_URL,
                            uniquePage,
                            MAX_UNIQUE_BYTES,
                            "unique",
                            false,
                            null
                    );
                } catch (IOException error) {
                    if (!uniquePage.isFile() && warning.isEmpty()) {
                        warning = "Unique Cameras classifications could not be refreshed.";
                    }
                }
            }

            UniqueCatalog uniqueCatalog = new UniqueCatalog();
            if (uniquePage.isFile()) {
                try {
                    uniqueCatalog = parseUniqueHtml(readSmallText(uniquePage, MAX_UNIQUE_BYTES));
                } catch (IOException ignored) {
                    // The main dataset remains usable; heuristic classification is used below.
                }
            }
            notifyProgress(progress, "Reading cameras for the visible map area…");
            ParsedDevices parsed = parseDataset(dataset, bounds, uniqueCatalog, progress);
            return new Result(
                    parsed.devices,
                    parsed.scanned,
                    parsed.unique,
                    refreshed,
                    stale,
                    warning
            );
        }
    }

    static long cachedDatasetBytes(Context context) {
        File cache = new File(context.getFilesDir(), DATA_CACHE);
        return cache.isFile() ? cache.length() : 0L;
    }

    static void clearCaches(Context context) {
        File data = new File(context.getFilesDir(), DATA_CACHE);
        File unique = new File(context.getFilesDir(), UNIQUE_CACHE);
        File dataDownload = new File(context.getFilesDir(), DATA_CACHE + ".download");
        File uniqueDownload = new File(context.getFilesDir(), UNIQUE_CACHE + ".download");
        if (data.exists()) {
            data.delete();
        }
        if (unique.exists()) {
            unique.delete();
        }
        if (dataDownload.exists()) {
            dataDownload.delete();
        }
        if (uniqueDownload.exists()) {
            uniqueDownload.delete();
        }
        context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE).edit().clear().apply();
    }

    static Device parseCameraLine(String line) {
        if (line == null || line.isEmpty()) {
            return null;
        }
        String[] parts = line.split("\\t", -1);
        if (parts.length < 15 || parts[0].isEmpty() || parts[1].isEmpty()) {
            return null;
        }
        try {
            Device device = new Device();
            device.rawLatitude = parts[0].trim();
            device.rawLongitude = parts[1].trim();
            device.latitude = Double.parseDouble(device.rawLatitude);
            device.longitude = Double.parseDouble(device.rawLongitude);
            if (!Double.isFinite(device.latitude) || !Double.isFinite(device.longitude)
                    || device.latitude < -90d || device.latitude > 90d
                    || device.longitude < -180d || device.longitude > 180d) {
                return null;
            }
            device.type = parts[2].trim();
            device.status = parts[3].trim();
            device.active = "1".equals(parts[4].trim())
                    || "inService".equalsIgnoreCase(device.status);
            device.name = parts[5].trim();
            device.features = parts[6].trim();
            device.rotationAngle = parts[7].trim();
            device.objectId = parts[8].trim();
            device.externalId = parts[9].trim();
            device.networkExternalId = parts[10].trim();
            device.organizationId = parts[11].trim();
            device.networkId = parts[12].trim();
            device.creationDate = parts[13].trim();
            device.parentExternalId = parts[14].trim();
            return device;
        } catch (NumberFormatException ignored) {
            return null;
        }
    }

    static UniqueCatalog parseUniqueHtml(String html) {
        UniqueCatalog catalog = new UniqueCatalog();
        if (html == null || html.isEmpty()) {
            return catalog;
        }

        Pattern objectPattern = Pattern.compile(
                "\\{\\s*title\\s*:\\s*\"((?:\\\\.|[^\"\\\\])*)\""
                        + "\\s*,\\s*lat\\s*:\\s*(-?\\d+(?:\\.\\d+)?)"
                        + "\\s*,\\s*lon\\s*:\\s*(-?\\d+(?:\\.\\d+)?)"
                        + "\\s*,\\s*flags\\s*:\\s*\\[([^\\]]*)\\]([^}]*)\\}",
                Pattern.DOTALL
        );
        Matcher objectMatcher = objectPattern.matcher(html);
        while (objectMatcher.find()) {
            String title = unescapeJavaScriptString(objectMatcher.group(1));
            double latitude = parseDoubleOrNaN(objectMatcher.group(2));
            double longitude = parseDoubleOrNaN(objectMatcher.group(3));
            if (!Double.isFinite(latitude) || !Double.isFinite(longitude)) {
                continue;
            }
            String categories = withNamedExample(parseFlagLabels(objectMatcher.group(4)));
            String note = extractQuotedProperty(objectMatcher.group(5), "note");
            catalog.add(new UniqueEntry("", title, latitude, longitude, categories, note));
        }

        Pattern detentionPattern = Pattern.compile(
                "detentionExample\\(\\s*\"((?:\\\\.|[^\"\\\\])*)\"\\s*,"
                        + "\\s*\"((?:\\\\.|[^\"\\\\])*)\"\\s*,"
                        + "\\s*(-?\\d+(?:\\.\\d+)?)\\s*,"
                        + "\\s*(-?\\d+(?:\\.\\d+)?)"
                        + "(?:\\s*,\\s*\"((?:\\\\.|[^\"\\\\])*)\")?\\s*\\)"
        );
        Matcher detentionMatcher = detentionPattern.matcher(html);
        while (detentionMatcher.find()) {
            String objectId = unescapeJavaScriptString(detentionMatcher.group(1));
            String title = unescapeJavaScriptString(detentionMatcher.group(2));
            double latitude = parseDoubleOrNaN(detentionMatcher.group(3));
            double longitude = parseDoubleOrNaN(detentionMatcher.group(4));
            String note = detentionMatcher.group(5) == null
                    ? "Detention/cell label at a dense same-coordinate cluster"
                    : unescapeJavaScriptString(detentionMatcher.group(5));
            if (Double.isFinite(latitude) && Double.isFinite(longitude)) {
                catalog.add(new UniqueEntry(
                        objectId,
                        title,
                        latitude,
                        longitude,
                        "Named example, Jail/prison/detention",
                        note
                ));
            }
        }
        return catalog;
    }

    static String humanType(String type) {
        if (type == null || type.trim().isEmpty()) {
            return "Unspecified device";
        }
        switch (type.trim()) {
            case "falcon": return "Falcon LPR";
            case "falconFlex": return "Falcon Flex";
            case "falconHighway": return "Falcon Highway";
            case "wing": return "Wing PTZ";
            case "wingGateway": return "Wing Gateway";
            case "wingUbicquia": return "Wing Ubicquia";
            case "wingApi": return "Wing API";
            case "picard": return "Picard";
            case "picardPtz": return "Picard PTZ";
            case "picardTrailer": return "Picard Trailer";
            case "condor": return "Condor Trailer";
            case "raven": return "Raven Audio";
            case "drone": return "Drone";
            case "droneDockingStation": return "Drone Dock";
            case "droneControllerBox": return "Drone Controller";
            case "droneRadar": return "Drone Radar";
            case "owl": return "OWL Radar";
            case "talkDown": return "TalkDown Speaker";
            case "trailer": return "Trailer";
            case "lprTrailer": return "LPR Trailer";
            case "sparrow": return "Sparrow";
            case "backhaulBox": return "Backhaul Box";
            case "multiEvidenceDevice": return "Multi-Evidence";
            case "avicore": return "Avicore";
            case "automotus": return "Automotus";
            case "external": return "External";
            case "factoryFixture": return "Factory Fixture";
            default:
                String spaced = type.replaceAll("([a-z])([A-Z])", "$1 $2");
                return Character.toUpperCase(spaced.charAt(0)) + spaced.substring(1);
        }
    }

    private static ParsedDevices parseDataset(
            File dataset,
            Bounds bounds,
            UniqueCatalog uniqueCatalog,
            ProgressListener progress
    ) throws IOException {
        ArrayList<Device> visible = new ArrayList<>();
        int scanned = 0;
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                new FileInputStream(dataset), StandardCharsets.UTF_8), 64 * 1024)) {
            String header = reader.readLine();
            if (header == null || !header.startsWith("lat\tlon\ttype\tstatus\tactive\tname\tfeatures")) {
                throw new IOException("Unexpected Flock Surveillance dataset header");
            }
            String line;
            while ((line = reader.readLine()) != null) {
                Device device = parseCameraLine(line);
                if (device == null) {
                    continue;
                }
                scanned++;
                if (bounds.contains(device.latitude, device.longitude)) {
                    applyUniqueInformation(device, uniqueCatalog);
                    visible.add(device);
                }
                if (scanned % 50000 == 0) {
                    notifyProgress(progress, "Scanned " + scanned
                            + " source cameras; " + visible.size() + " in view…");
                }
            }
        }
        applyCoLocationInformation(visible);
        int unique = 0;
        for (Device device : visible) {
            if (device.unique) {
                unique++;
            }
        }
        return new ParsedDevices(visible, scanned, unique);
    }

    private static void applyUniqueInformation(Device device, UniqueCatalog catalog) {
        UniqueEntry entry = catalog.match(device);
        if (entry != null) {
            device.unique = true;
            device.uniqueCategories = entry.categories.isEmpty()
                    ? "Named example"
                    : entry.categories;
            device.uniqueNote = entry.note.isEmpty()
                    ? "Listed on the Flock Surveillance Unique Cameras page."
                    : entry.note;
            return;
        }
        if (catalog.size() == 0) {
            String category = heuristicUniqueCategory(device);
            if (!category.isEmpty()) {
                device.unique = true;
                device.uniqueCategories = category;
                device.uniqueNote = "Matched an offline Unique Cameras review category; "
                        + "confirm against the live source page when connected.";
            }
        }
    }

    private static String heuristicUniqueCategory(Device device) {
        String text = (device.name + " " + device.type).toLowerCase(Locale.ROOT);
        LinkedHashSet<String> categories = new LinkedHashSet<>();
        if (containsAny(text, "school", "academy", "elementary", "jr high", "high school",
                "learning center", "childcare", "restroom", "locker room")) {
            categories.add("School/childcare");
        }
        if (containsAny(text, "jail", "prison", "detention", "holding cell", " cell ",
                "booking", "juvenile holding", "shower")) {
            categories.add("Jail/prison/detention");
        }
        if (text.contains("fbi")) {
            categories.add("FBI");
        }
        if (text.contains("weapon detection")) {
            categories.add("Weapon detection");
        }
        if (containsAny(text, "family violence", "sexual assault")) {
            categories.add("Sensitive public-service");
        }
        if (text.contains("gateway")) {
            categories.add("Gateway review");
        }
        if ("wingApi".equals(device.type) || text.contains(" api ")) {
            categories.add("API review");
        }
        return join(categories);
    }

    private static void applyCoLocationInformation(List<Device> devices) {
        Map<String, ArrayList<Device>> exactGroups = new HashMap<>();
        for (Device device : devices) {
            exactGroups.computeIfAbsent(device.coordinateKey(), key -> new ArrayList<>())
                    .add(device);
        }
        for (ArrayList<Device> group : exactGroups.values()) {
            for (Device device : group) {
                device.coLocatedCount = group.size();
                for (Device neighbor : group) {
                    if (neighbor == device) {
                        continue;
                    }
                    if (device.coLocatedNames.size() >= 3) {
                        break;
                    }
                    device.coLocatedNames.add(
                            neighbor.name.isEmpty() ? "Unnamed device" : neighbor.name);
                }
            }
        }

        // The Unique Cameras page treats points within this small distance as one dense cluster.
        for (Device device : devices) {
            if (!device.unique) {
                continue;
            }
            int nearbyCount = 0;
            ArrayList<String> nearbyNames = new ArrayList<>();
            for (Device candidate : devices) {
                if (Math.hypot(
                        device.latitude - candidate.latitude,
                        device.longitude - candidate.longitude
                ) <= UNIQUE_COORDINATE_TOLERANCE) {
                    nearbyCount++;
                    if (candidate != device && nearbyNames.size() < 3) {
                        nearbyNames.add(candidate.name.isEmpty()
                                ? "Unnamed device" : candidate.name);
                    }
                }
            }
            if (nearbyCount > device.coLocatedCount) {
                device.coLocatedCount = nearbyCount;
                device.coLocatedNames.clear();
                device.coLocatedNames.addAll(nearbyNames);
            }
        }
    }

    private static boolean downloadToCache(
            Context context,
            String urlString,
            File cache,
            long maximumBytes,
            String preferencePrefix,
            boolean validateDataset,
            ProgressListener progress
    ) throws IOException {
        SharedPreferences preferences = context.getSharedPreferences(
                PREFERENCES, Context.MODE_PRIVATE);
        HttpURLConnection connection = (HttpURLConnection) new URL(urlString).openConnection();
        connection.setConnectTimeout(20000);
        connection.setReadTimeout(120000);
        connection.setInstanceFollowRedirects(true);
        connection.setRequestProperty("Accept", validateDataset
                ? "text/tab-separated-values,text/plain;q=0.9,*/*;q=0.5"
                : "text/html,*/*;q=0.5");
        connection.setRequestProperty("User-Agent", USER_AGENT);
        if (cache.isFile()) {
            String etag = preferences.getString(preferencePrefix + "_etag", "");
            String lastModified = preferences.getString(
                    preferencePrefix + "_last_modified", "");
            if (!etag.isEmpty()) {
                connection.setRequestProperty("If-None-Match", etag);
            }
            if (!lastModified.isEmpty()) {
                connection.setRequestProperty("If-Modified-Since", lastModified);
            }
        }

        int responseCode = connection.getResponseCode();
        if (responseCode == HttpURLConnection.HTTP_NOT_MODIFIED && cache.isFile()) {
            connection.disconnect();
            cache.setLastModified(System.currentTimeMillis());
            return false;
        }
        if (responseCode != HttpURLConnection.HTTP_OK) {
            connection.disconnect();
            throw new IOException("Flock Surveillance HTTP " + responseCode);
        }
        long contentLength = connection.getContentLengthLong();
        if (contentLength > maximumBytes) {
            connection.disconnect();
            throw new IOException("Flock Surveillance response exceeds the cache limit");
        }
        String responseEtag = nonNull(connection.getHeaderField("ETag"));
        String responseLastModified = nonNull(connection.getHeaderField("Last-Modified"));

        File temporary = new File(cache.getParentFile(), cache.getName() + ".download");
        long downloaded = 0L;
        long nextProgress = 1024L * 1024L;
        try (InputStream input = new BufferedInputStream(connection.getInputStream(), 64 * 1024);
             FileOutputStream output = new FileOutputStream(temporary, false)) {
            byte[] buffer = new byte[64 * 1024];
            int count;
            while ((count = input.read(buffer)) != -1) {
                downloaded += count;
                if (downloaded > maximumBytes) {
                    throw new IOException("Flock Surveillance response exceeds the cache limit");
                }
                output.write(buffer, 0, count);
                if (downloaded >= nextProgress && progress != null) {
                    String total = contentLength > 0
                            ? " of " + Math.max(1L, contentLength / (1024L * 1024L)) + " MB"
                            : "";
                    notifyProgress(progress, "Downloaded "
                            + (downloaded / (1024L * 1024L)) + " MB" + total + "…");
                    nextProgress += 1024L * 1024L;
                }
            }
            output.getFD().sync();
        } finally {
            connection.disconnect();
        }
        if (downloaded == 0L) {
            throw new IOException("Flock Surveillance returned an empty response");
        }
        if (validateDataset && !validDatasetCache(temporary)) {
            throw new IOException("Flock Surveillance returned an unexpected dataset format");
        }
        replaceFile(temporary, cache);
        preferences.edit()
                .putString(preferencePrefix + "_etag", responseEtag)
                .putString(preferencePrefix + "_last_modified", responseLastModified)
                .apply();
        return true;
    }

    private static void replaceFile(File temporary, File destination) throws IOException {
        if (destination.exists() && !destination.delete()) {
            throw new IOException("Could not replace the saved camera dataset");
        }
        if (!temporary.renameTo(destination)) {
            throw new IOException("Could not install the camera dataset");
        }
        destination.setLastModified(System.currentTimeMillis());
    }

    private static boolean validDatasetCache(File file) {
        if (!file.isFile() || file.length() < 100L || file.length() > MAX_DATA_BYTES) {
            return false;
        }
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                new FileInputStream(file), StandardCharsets.UTF_8))) {
            String header = reader.readLine();
            return header != null
                    && header.startsWith("lat\tlon\ttype\tstatus\tactive\tname\tfeatures");
        } catch (IOException error) {
            return false;
        }
    }

    private static boolean isFresh(File file) {
        return file.isFile()
                && System.currentTimeMillis() - file.lastModified() < CACHE_FRESH_MILLIS;
    }

    private static String readSmallText(File file, long maximumBytes) throws IOException {
        try (InputStream input = new FileInputStream(file);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = input.read(buffer)) != -1) {
                if (output.size() + count > maximumBytes) {
                    throw new IOException("Unique Cameras page exceeds the cache limit");
                }
                output.write(buffer, 0, count);
            }
            return output.toString("UTF-8");
        }
    }

    private static String sourceUrl(String objectId, double latitude, double longitude) {
        if (objectId != null && !objectId.isEmpty()) {
            return MAP_URL + "?focus=" + objectId;
        }
        return MAP_URL + "?lat=" + latitude + "&lon=" + longitude;
    }

    private static String parseFlagLabels(String flagsText) {
        if (flagsText == null || flagsText.isEmpty()) {
            return "";
        }
        ArrayList<String> labels = new ArrayList<>();
        Matcher matcher = Pattern.compile("\"((?:\\\\.|[^\"\\\\])*)\"")
                .matcher(flagsText);
        while (matcher.find()) {
            String flag = unescapeJavaScriptString(matcher.group(1));
            String label = flagLabel(flag);
            if (!label.isEmpty() && !labels.contains(label)) {
                labels.add(label);
            }
        }
        return join(labels);
    }

    private static String flagLabel(String flag) {
        switch (flag) {
            case "highlighted": return "Named example";
            case "school": return "School/childcare";
            case "schoolGateway": return "School gateways";
            case "correction": return "Jail/prison/detention";
            case "fbi": return "FBI";
            case "weaponDetection": return "Weapon detection";
            case "sensitiveService": return "Sensitive public-service";
            case "publicGateway": return "Public facility gateways";
            case "api": return "API review";
            case "gateway": return "All gateways";
            case "all": return "All flagged";
            default: return flag;
        }
    }

    private static String extractQuotedProperty(String text, String property) {
        if (text == null || text.isEmpty()) {
            return "";
        }
        Pattern pattern = Pattern.compile(
                Pattern.quote(property) + "\\s*:\\s*\"((?:\\\\.|[^\"\\\\])*)\"");
        Matcher matcher = pattern.matcher(text);
        return matcher.find() ? unescapeJavaScriptString(matcher.group(1)) : "";
    }

    private static String withNamedExample(String categories) {
        return categories == null || categories.isEmpty()
                ? "Named example"
                : "Named example, " + categories;
    }

    private static String unescapeJavaScriptString(String value) {
        if (value == null || value.indexOf('\\') < 0) {
            return value == null ? "" : value;
        }
        StringBuilder result = new StringBuilder(value.length());
        boolean escaped = false;
        for (int index = 0; index < value.length(); index++) {
            char current = value.charAt(index);
            if (!escaped) {
                if (current == '\\') {
                    escaped = true;
                } else {
                    result.append(current);
                }
                continue;
            }
            switch (current) {
                case 'n': result.append('\n'); break;
                case 'r': result.append('\r'); break;
                case 't': result.append('\t'); break;
                case '"': result.append('"'); break;
                case '\\': result.append('\\'); break;
                default: result.append(current); break;
            }
            escaped = false;
        }
        if (escaped) {
            result.append('\\');
        }
        return result.toString();
    }

    private static double parseDoubleOrNaN(String value) {
        try {
            return Double.parseDouble(value);
        } catch (Exception ignored) {
            return Double.NaN;
        }
    }

    private static boolean containsAny(String text, String... needles) {
        for (String needle : needles) {
            if (text.contains(needle)) {
                return true;
            }
        }
        return false;
    }

    private static String join(Iterable<String> values) {
        StringBuilder result = new StringBuilder();
        for (String value : values) {
            if (value == null || value.isEmpty()) {
                continue;
            }
            if (result.length() > 0) {
                result.append(", ");
            }
            result.append(value);
        }
        return result.toString();
    }

    private static String nonNull(String value) {
        return value == null ? "" : value;
    }

    private static void notifyProgress(ProgressListener listener, String message) {
        if (listener != null) {
            listener.onProgress(message);
        }
    }
}
