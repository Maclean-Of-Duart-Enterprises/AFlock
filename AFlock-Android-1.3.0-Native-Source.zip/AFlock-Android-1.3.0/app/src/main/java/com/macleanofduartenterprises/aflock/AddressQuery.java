package com.macleanofduartenterprises.aflock;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Pure-Java query normalization for the Android SQLite FTS index. */
public final class AddressQuery {
    private AddressQuery() {
    }

    public static String toFtsPrefixQuery(String input) {
        if (input == null) {
            return "";
        }
        String normalized = input.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]+", " ").trim();
        if (normalized.isEmpty()) {
            return "";
        }
        String[] pieces = normalized.split("\\s+");
        List<String> tokens = new ArrayList<>();
        for (String piece : pieces) {
            if (!piece.isEmpty()) {
                tokens.add("\"" + piece.replace("\"", "") + "\"*");
            }
        }
        return join(tokens, " AND ");
    }

    private static String join(List<String> values, String separator) {
        StringBuilder result = new StringBuilder();
        for (String value : values) {
            if (result.length() > 0) {
                result.append(separator);
            }
            result.append(value);
        }
        return result.toString();
    }
}
