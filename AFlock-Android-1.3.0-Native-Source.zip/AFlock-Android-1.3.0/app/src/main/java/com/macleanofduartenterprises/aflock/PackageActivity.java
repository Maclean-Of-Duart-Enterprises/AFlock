package com.macleanofduartenterprises.aflock;

import android.app.*;
import android.os.*;
import android.content.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.security.*;
import java.util.*;

/** User-supplied, licensed offline map package download with SHA-256 validation.
 * Does not download from public OSM tile servers. Packages must be compatible with the
 * selected map renderer; importing arbitrary PMTiles/MBTiles is not implemented here. */
public class PackageActivity extends ThemedActivity {
 private TextView status; private EditText url, sha; private volatile boolean cancel;
 private File packageDir(){File d=new File(getFilesDir(),"licensed-packages");d.mkdirs();return d;}
 @Override public void onCreate(Bundle state){super.onCreate(state);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
  TextView warning=new TextView(this);warning.setText("Download a map package only from a provider that permits offline use. Enter the published SHA-256 checksum. This manager verifies files but does not automatically render every format. Worldwide coverage requires a separately supplied licensed dataset.");root.addView(warning);
  url=new EditText(this);url.setHint("HTTPS package URL");url.setSingleLine(true);root.addView(url);
  sha=new EditText(this);sha.setHint("Expected SHA-256 (64 hexadecimal characters)");sha.setSingleLine(true);root.addView(sha);
  Button download=new Button(this);download.setText("Download / resume and verify");root.addView(download);
  Button manage=new Button(this);manage.setText("Manage packages");root.addView(manage);
  Button stop=new Button(this);stop.setText("Pause download");root.addView(stop);
  status=new TextView(this);root.addView(status);setContentView(root);
  download.setOnClickListener(v->startDownload());manage.setOnClickListener(v->manage());stop.setOnClickListener(v->{cancel=true;status.setText("Pause requested; partial download retained.");});
 }
 private void startDownload(){String address=url.getText().toString().trim(),expected=sha.getText().toString().trim().toLowerCase(Locale.ROOT);
  if(!address.startsWith("https://")||!expected.matches("[0-9a-f]{64}")){status.setText("An HTTPS URL and valid SHA-256 checksum are required.");return;}
  cancel=false;status.setText("Starting download...");new Thread(()->{
   String key=expected.substring(0,24);File partial=new File(packageDir(),key+".part"),complete=new File(packageDir(),key+".package");
   try {long offset=partial.length();HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(30000);c.setInstanceFollowRedirects(false);
    if(offset>0)c.setRequestProperty("Range","bytes="+offset+"-");int code=c.getResponseCode();if(code!=200&&code!=206)throw new IOException("HTTP "+code);
    if(code==206&&offset==0)throw new IOException("Unexpected partial response");
    if(code==206){String range=c.getHeaderField("Content-Range");if(range==null||!range.startsWith("bytes "+offset+"-"))throw new IOException("Invalid Content-Range; refusing corrupted resume");}
    boolean append=code==206;long free=new android.os.StatFs(packageDir().getAbsolutePath()).getAvailableBytes();long remaining=c.getContentLengthLong();if(remaining>0&&remaining+64L*1024*1024>free)throw new IOException("Insufficient free storage");
    try(InputStream in=c.getInputStream();OutputStream out=new FileOutputStream(partial,append)){byte[] buf=new byte[65536];int n;long received=append?offset:0;while(!cancel&&(n=in.read(buf))!=-1){out.write(buf,0,n);received+=n;if(received%(8*1024*1024)<65536){long progress=received;runOnUiThread(()->status.setText("Downloaded "+progress/1048576+" MiB"));}}}
    c.disconnect();if(cancel)return;MessageDigest digest=MessageDigest.getInstance("SHA-256");try(InputStream in=new FileInputStream(partial)){byte[] buf=new byte[65536];int n;while((n=in.read(buf))!=-1)digest.update(buf,0,n);}
    StringBuilder hex=new StringBuilder();for(byte b:digest.digest())hex.append(String.format(Locale.ROOT,"%02x",b&255));if(!expected.equals(hex.toString()))throw new IOException("SHA-256 mismatch: package not installed");
    if(complete.exists()&&!complete.delete())throw new IOException("Cannot replace old package");if(!partial.renameTo(complete))throw new IOException("Cannot install package");
    runOnUiThread(()->status.setText("Checksum verified. Saved "+complete.getName()+" ("+complete.length()/1048576+" MiB). Renderer compatibility must be checked separately."));
   }catch(Exception e){runOnUiThread(()->status.setText("Download failed: "+e.getMessage()+". Partial data retained; resume with same URL and checksum."));}
  }).start();}
 private void manage(){File[] files=packageDir().listFiles();if(files==null||files.length==0){status.setText("No map packages stored.");return;}
  Arrays.sort(files,Comparator.comparing(File::getName));String[] names=new String[files.length];for(int i=0;i<files.length;i++)names[i]=files[i].getName()+" ("+files[i].length()/1048576+" MiB)";
  new AlertDialog.Builder(this).setTitle("Downloaded packages").setItems(names,(d,i)->new AlertDialog.Builder(this).setTitle(names[i]).setMessage("Delete this file?").setNegativeButton("Cancel",null).setPositiveButton("Delete",(x,y)->{boolean ok=files[i].delete();status.setText(ok?"Deleted":"Delete failed");}).show()).setNegativeButton("Close",null).show();}
}
