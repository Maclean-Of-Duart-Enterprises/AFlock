package com.macleanofduartenterprises.aflock;
import android.content.Context;
import org.json.*;
import java.io.*;
import java.util.*;
/** Shared synchronized store for foreground and background camera-source results. */
public final class RecordStore {
 private RecordStore(){}
 public static synchronized void merge(Context ctx,JSONArray elements)throws Exception {
  JSONArray normalized=new JSONArray();
  for(int i=0;i<elements.length();i++){
   JSONObject e=elements.optJSONObject(i);if(e==null)continue;JSONObject tags=e.optJSONObject("tags");if(tags==null)continue;
   JSONObject center=e.optJSONObject("center");double lat=e.has("lat")?e.optDouble("lat"):center==null?Double.NaN:center.optDouble("lat");
   double lon=e.has("lon")?e.optDouble("lon"):center==null?Double.NaN:center.optDouble("lon");if(Double.isNaN(lat)||Double.isNaN(lon))continue;
   boolean disused="yes".equals(tags.optString("disused"))||"yes".equals(tags.optString("abandoned"));
   String osmType=e.optString("type","node");long osmId=e.optLong("id");
   JSONObject r=new JSONObject();r.put("lat",lat);r.put("lon",lon);r.put("name",tags.optString("name","Unnamed surveillance device"));r.put("kind",tags.optString("surveillance:type",tags.optString("camera:type","Unspecified")));
   r.put("operator",tags.optString("operator","Unknown"));r.put("status",disused?"disused":"OSM community record");r.put("active",!disused);r.put("disused",disused);
   r.put("source","openstreetmap");r.put("sourceId",osmType+"/"+osmId);r.put("sourceUrl","https://www.openstreetmap.org/"+osmType+"/"+osmId);
   r.put("osmType",osmType);r.put("osmId",osmId);r.put("tags",tags);normalized.put(r);
  }
  mergeNormalized(ctx,normalized);
 }
 public static synchronized void mergeNormalized(Context ctx,JSONArray incoming)throws Exception {
  File file=new File(ctx.getFilesDir(),"records.json");JSONArray previous=read(file);
  LinkedHashMap<String,JSONObject> records=new LinkedHashMap<>();
  for(int i=0;i<previous.length();i++){JSONObject record=previous.optJSONObject(i);if(record!=null)records.put(recordKey(record),record);}
  for(int i=0;i<incoming.length();i++){JSONObject record=incoming.optJSONObject(i);if(record!=null)records.put(recordKey(record),record);}
  JSONArray result=new JSONArray();for(JSONObject r:records.values())result.put(r);
  File tmp=new File(ctx.getFilesDir(),"records.json.tmp");try(FileOutputStream out=new FileOutputStream(tmp)){out.write(result.toString().getBytes("UTF-8"));out.getFD().sync();}
  if(!tmp.renameTo(file)){if(file.exists()&&!file.delete())throw new IOException("Unable to replace cache");if(!tmp.renameTo(file))throw new IOException("Unable to install cache");}
 }
 private static String recordKey(JSONObject record){
  String source=record.optString("source","");String sourceId=record.optString("sourceId","");
  if(!source.isEmpty()&&!sourceId.isEmpty())return source+"/"+sourceId;
  String osmType=record.optString("osmType","");long osmId=record.optLong("osmId");
  if(!osmType.isEmpty())return "openstreetmap/"+osmType+"/"+osmId;
  return source+"/"+record.optDouble("lat")+"/"+record.optDouble("lon")+"/"+record.optString("name");
 }
 private static JSONArray read(File file){try(FileInputStream in=new FileInputStream(file)){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){out.write(b,0,n);if(out.size()>50000000)throw new IOException("Cache too large");}return new JSONArray(out.toString("UTF-8"));}catch(Exception e){return new JSONArray();}}
}
