package com.macleanofduartenterprises.aflock;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Full-text place/address search that reads only the on-device SQLite index. */
public final class OfflineAddressSearchActivity extends ThemedActivity {
    private final List<AddressDatabase.AddressResult> results = new ArrayList<>();
    private final List<String> labels = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private TextView status;
    private EditText query;
    private Button downloadArea;
    private double south;
    private double west;
    private double north;
    private double east;
    private boolean hasBounds;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        south = getIntent().getDoubleExtra("south", Double.NaN);
        west = getIntent().getDoubleExtra("west", Double.NaN);
        north = getIntent().getDoubleExtra("north", Double.NaN);
        east = getIntent().getDoubleExtra("east", Double.NaN);
        hasBounds = !Double.isNaN(south) && !Double.isNaN(west)
                && !Double.isNaN(north) && !Double.isNaN(east)
                && south < north && west < east;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(16, 12, 16, 12);

        TextView explanation = new TextView(this);
        explanation.setText(
                "Search works without a connection. AFlock includes a worldwide populated-place index; "
                        + "download the visible area to add detailed OpenStreetMap street and house-number records."
        );
        root.addView(explanation);

        LinearLayout searchRow = new LinearLayout(this);
        query = new EditText(this);
        query.setSingleLine(true);
        query.setHint("Address, street, city, postcode, or country");
        Button search = new Button(this);
        search.setText("Search offline");
        searchRow.addView(query, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        searchRow.addView(search);
        root.addView(searchRow);

        downloadArea = new Button(this);
        downloadArea.setText("Download detailed addresses for visible map area");
        downloadArea.setEnabled(hasBounds);
        root.addView(downloadArea);

        Button dataNotice = new Button(this);
        dataNotice.setText("Offline data and attribution");
        root.addView(dataNotice);

        status = new TextView(this);
        status.setPadding(8, 10, 8, 10);
        root.addView(status);

        ListView list = new ListView(this);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, labels);
        list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1
        ));
        setContentView(root);

        search.setOnClickListener(view -> searchOffline());
        downloadArea.setOnClickListener(view -> downloadVisibleArea());
        dataNotice.setOnClickListener(view -> showAttribution());
        list.setOnItemClickListener((parent, view, position, id) -> selectResult(position));

        prepareWorldIndex();
    }

    private void prepareWorldIndex() {
        AddressDatabase database = AddressDatabase.get(this);
        status.setText(database.isWorldIndexReady()
                ? database.countAll() + " offline places/addresses ready in " + database.detailedPackCount() + " detailed pack(s)."
                : "Preparing the bundled worldwide place index for first use…");
        database.ensureWorldIndexAsync(this, new AddressDatabase.ImportCallback() {
            @Override
            public void onProgress(String message) {
                status.setText(message);
            }

            @Override
            public void onComplete(int recordCount) {
                status.setText(recordCount + " worldwide places ready for offline search."
                        + (hasBounds ? " You can also download detailed addresses for the visible map area." : ""));
            }

            @Override
            public void onError(String message) {
                status.setText(message);
            }
        });
    }

    private void searchOffline() {
        String text = query.getText().toString().trim();
        if (text.length() < 2) {
            status.setText("Enter at least two letters or numbers.");
            return;
        }
        status.setText("Searching the on-device index…");
        new Thread(() -> {
            List<AddressDatabase.AddressResult> found = AddressDatabase.get(this).search(text, 100);
            runOnUiThread(() -> {
                results.clear();
                results.addAll(found);
                labels.clear();
                for (AddressDatabase.AddressResult item : found) {
                    labels.add(item.name + "\n" + item.displayAddress + " · " + item.source);
                }
                adapter.notifyDataSetChanged();
                status.setText(found.size() + " offline result(s). No network request was made.");
            });
        }, "AFlock-offline-address-search").start();
    }

    private void downloadVisibleArea() {
        if (!hasBounds) {
            status.setText("Open address search from a map to download the current area.");
            return;
        }
        downloadArea.setEnabled(false);
        AddressPackDownloader.download(this, south, west, north, east, new AddressPackDownloader.Callback() {
            @Override
            public void onProgress(String message) {
                status.setText(message);
            }

            @Override
            public void onComplete(int recordCount) {
                downloadArea.setEnabled(true);
                status.setText(recordCount + " detailed place/address record(s) saved. They are now searchable offline.");
            }

            @Override
            public void onError(String message) {
                downloadArea.setEnabled(true);
                status.setText(message);
            }
        });
    }

    private void selectResult(int position) {
        if (position < 0 || position >= results.size()) {
            return;
        }
        AddressDatabase.AddressResult result = results.get(position);
        new AlertDialog.Builder(this)
                .setTitle(result.name)
                .setMessage(result.displayAddress + "\n\nCoordinates: "
                        + String.format(Locale.US, "%.6f, %.6f", result.latitude, result.longitude)
                        + "\nSource: " + result.source)
                .setNegativeButton("Close", null)
                .setPositiveButton("Show on map", (dialog, which) -> {
                    getSharedPreferences("map_target", MODE_PRIVATE)
                            .edit()
                            .putBoolean("pending", true)
                            .putString("latitude", Double.toString(result.latitude))
                            .putString("longitude", Double.toString(result.longitude))
                            .apply();
                    setResult(RESULT_OK);
                    finish();
                })
                .show();
    }

    private void showAttribution() {
        new AlertDialog.Builder(this)
                .setTitle("Offline data")
                .setMessage(
                        "Worldwide places: GeoNames, CC BY 4.0.\n"
                                + "Detailed address packs: © OpenStreetMap contributors, ODbL.\n"
                                + "Country geometry: Natural Earth, public domain.\n\n"
                                + "Detailed packs cover only areas you explicitly download. The bundled worldwide index "
                                + "covers populated places, not every street number on Earth."
                )
                .setPositiveButton("OK", null)
                .show();
    }
}
