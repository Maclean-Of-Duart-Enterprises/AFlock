package com.macleanofduartenterprises.aflock;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.view.View;
import android.view.Window;

final class ThemeManager {
    static final String SYSTEM = "system";
    static final String LIGHT = "light";
    static final String DARK = "dark";

    private static final String PREFERENCES = "appearance";
    private static final String THEME_KEY = "theme";

    private ThemeManager() {
    }

    static void apply(Activity activity) {
        activity.setTheme(isDark(activity)
                ? R.style.Theme_AFlock_Dark
                : R.style.Theme_AFlock_Light);
    }

    static void styleSystemBars(Activity activity) {
        boolean dark = isDark(activity);
        Window window = activity.getWindow();
        int barColor = dark ? Color.rgb(25, 32, 38) : Color.rgb(232, 238, 243);
        window.setStatusBarColor(barColor);
        window.setNavigationBarColor(barColor);

        int visibility = window.getDecorView().getSystemUiVisibility();
        if (dark) {
            visibility &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                visibility &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
        } else {
            visibility |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                visibility |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
        }
        window.getDecorView().setSystemUiVisibility(visibility);
    }

    static String getChoice(Context context) {
        return normalizeChoice(context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
                .getString(THEME_KEY, SYSTEM));
    }

    static void setChoice(Context context, String choice) {
        context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
                .edit()
                .putString(THEME_KEY, normalizeChoice(choice))
                .apply();
    }

    static String normalizeChoice(String choice) {
        if (LIGHT.equals(choice) || DARK.equals(choice)) {
            return choice;
        }
        return SYSTEM;
    }

    static boolean isDark(Context context) {
        String choice = getChoice(context);
        if (DARK.equals(choice)) {
            return true;
        }
        if (LIGHT.equals(choice)) {
            return false;
        }
        int nightMode = context.getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK;
        return nightMode == Configuration.UI_MODE_NIGHT_YES;
    }

    static int windowBackground(Context context) {
        return isDark(context) ? Color.rgb(18, 18, 18) : Color.rgb(250, 250, 250);
    }

    static int panelBackground(Context context) {
        return isDark(context) ? Color.rgb(31, 38, 43) : Color.rgb(245, 247, 249);
    }

    static int borderColor(Context context) {
        return isDark(context) ? Color.rgb(144, 202, 249) : Color.rgb(38, 86, 112);
    }

    static int primaryTextColor(Context context) {
        return isDark(context) ? Color.WHITE : Color.rgb(28, 32, 35);
    }
}
