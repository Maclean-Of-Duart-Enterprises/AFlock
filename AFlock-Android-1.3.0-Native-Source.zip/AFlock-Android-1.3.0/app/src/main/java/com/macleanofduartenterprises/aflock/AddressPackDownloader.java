package com.macleanofduartenterprises.aflock;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;

/** Downloads a bounded OSM address/place snapshot and converts it to an offline search pack. */
public final class AddressPackDownloader {
    private static final double MAXIMUM_SPAN_DEGREES = 0.50;
    private static final int MAXIMUM_RESPONSE_BYTES = 50 * 1024 * 1024;

    private AddressPackDownloader() {
    }

    public static void download(
            Context context,
            double south,
            double west,
            double north,
            double east,
            Callback callback
    ) {
        Handler main = new Handler(Looper.getMainLooper());
        if (!(south < north && west < east)) {
            callback.onError("The current map bounds are invalid.");
            return;
        }
        if (north - south > MAXIMUM_SPAN_DEGREES || east - west > MAXIMUM_SPAN_DEGREES) {
            callback.onError("Zoom in further. Detailed offline address packs are limited to 0.5° by 0.5° per download.");
            return;
        }

        Context appContext = context.getApplicationContext();
        new Thread(() -> {
            try {
                main.post(() -> callback.onProgress("Downloading names and addresses for the visible area…"));
                String bbox = String.format(Locale.US, "%.7f,%.7f,%.7f,%.7f", south, west, north, east);
                String query = "[out:json][timeout:90];("
                        + "nwr[\"addr:housenumber\"](" + bbox + ");"
                        + "nwr[\"addr:street\"](" + bbox + ");"
                        + "nwr[\"place\"][\"name\"](" + bbox + ");"
                        + "nwr[\"amenity\"][\"name\"](" + bbox + ");"
                        + "nwr[\"shop\"][\"name\"](" + bbox + ");"
                        + ");out center tags 50000;";

                OverpassClient.Response response = OverpassClient.execute(
                        query,
                        20_000,
                        120_000,
                        MAXIMUM_RESPONSE_BYTES,
                        message -> main.post(() -> callback.onProgress(message))
                );

                JSONObject responseJson = new JSONObject(
                        new String(response.getBody(), StandardCharsets.UTF_8)
                );
                JSONArray elements = responseJson.getJSONArray("elements");
                LinkedHashMap<String, AddressDatabase.AddressEntry> unique = new LinkedHashMap<>();
                for (int index = 0; index < elements.length(); index++) {
                    JSONObject element = elements.optJSONObject(index);
                    if (element == null) {
                        continue;
                    }
                    JSONObject tags = element.optJSONObject("tags");
                    if (tags == null) {
                        continue;
                    }
                    JSONObject center = element.optJSONObject("center");
                    double latitude = element.has("lat")
                            ? element.optDouble("lat", Double.NaN)
                            : center == null ? Double.NaN : center.optDouble("lat", Double.NaN);
                    double longitude = element.has("lon")
                            ? element.optDouble("lon", Double.NaN)
                            : center == null ? Double.NaN : center.optDouble("lon", Double.NaN);
                    if (Double.isNaN(latitude) || Double.isNaN(longitude)) {
                        continue;
                    }

                    String houseNumber = tags.optString("addr:housenumber", "").trim();
                    String street = firstNonEmpty(tags.optString("addr:street"), tags.optString("addr:place"));
                    String city = firstNonEmpty(
                            tags.optString("addr:city"),
                            tags.optString("addr:town"),
                            tags.optString("addr:village"),
                            tags.optString("place")
                    );
                    String state = tags.optString("addr:state", "").trim();
                    String postcode = tags.optString("addr:postcode", "").trim();
                    String country = tags.optString("addr:country", "").trim();
                    String named = tags.optString("name", "").trim();
                    String streetAddress = join(" ", houseNumber, street);
                    String name = firstNonEmpty(named, streetAddress, city, "Mapped place");
                    String displayAddress = join(", ", firstNonEmpty(streetAddress, named), city, state, postcode, country);

                    AddressDatabase.AddressEntry entry = new AddressDatabase.AddressEntry();
                    entry.stableId = "osm:" + element.optString("type", "node") + "/" + element.optLong("id");
                    entry.name = name;
                    entry.displayAddress = firstNonEmpty(displayAddress, name);
                    entry.street = street;
                    entry.city = city;
                    entry.state = state;
                    entry.postcode = postcode;
                    entry.country = country;
                    entry.aliases = tags.optString("alt_name", "") + " " + tags.optString("old_name", "");
                    entry.latitude = latitude;
                    entry.longitude = longitude;
                    entry.source = "OpenStreetMap";
                    entry.updatedAt = System.currentTimeMillis();
                    unique.put(entry.stableId, entry);
                }

                List<AddressDatabase.AddressEntry> entries = new ArrayList<>(unique.values());
                String packId = String.format(
                        Locale.US,
                        "osm_%.4f_%.4f_%.4f_%.4f",
                        south,
                        west,
                        north,
                        east
                );
                String label = String.format(
                        Locale.US,
                        "OSM %.3f, %.3f to %.3f, %.3f",
                        south,
                        west,
                        north,
                        east
                );
                int count = AddressDatabase.get(appContext).replaceDetailedPack(
                        packId,
                        label,
                        south,
                        west,
                        north,
                        east,
                        entries
                );
                main.post(() -> callback.onComplete(count));
            } catch (Exception error) {
                main.post(() -> callback.onError("Address-pack download failed: " + safeMessage(error)));
            }
        }, "AFlock-address-pack").start();
    }

    private static String firstNonEmpty(String... values) {
        for (String value : values) {
            if (value != null && !value.trim().isEmpty()) {
                return value.trim();
            }
        }
        return "";
    }

    private static String join(String separator, String... values) {
        StringBuilder result = new StringBuilder();
        for (String value : values) {
            if (value != null && !value.trim().isEmpty()) {
                if (result.length() > 0) {
                    result.append(separator);
                }
                result.append(value.trim());
            }
        }
        return result.toString();
    }

    private static String safeMessage(Throwable error) {
        return error.getMessage() == null ? error.getClass().getSimpleName() : error.getMessage();
    }

    public interface Callback {
        void onProgress(String message);

        void onComplete(int recordCount);

        void onError(String message);
    }
}
