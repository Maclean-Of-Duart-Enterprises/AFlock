package com.macleanofduartenterprises.aflock;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;

/** Metadata stored alongside MapLibre offline regions. */
public final class OfflineRegionMetadata {
    public static final int SCHEMA_VERSION = 1;

    public final String type;
    public final String stableId;
    public final String name;
    public final String styleUrl;
    public final long createdAt;
    public final long updateRequestedAt;

    private OfflineRegionMetadata(
            String type,
            String stableId,
            String name,
            String styleUrl,
            long createdAt,
            long updateRequestedAt
    ) {
        this.type = type;
        this.stableId = stableId;
        this.name = name;
        this.styleUrl = styleUrl;
        this.createdAt = createdAt;
        this.updateRequestedAt = updateRequestedAt;
    }

    public static OfflineRegionMetadata create(String type, String stableId, String name, String styleUrl) {
        long now = System.currentTimeMillis();
        return new OfflineRegionMetadata(type, stableId, name, styleUrl, now, now);
    }

    public static OfflineRegionMetadata parse(byte[] bytes) {
        if (bytes == null || bytes.length == 0) {
            return new OfflineRegionMetadata("legacy", "", "Legacy offline region", "", 0L, 0L);
        }
        try {
            JSONObject json = new JSONObject(new String(bytes, StandardCharsets.UTF_8));
            return new OfflineRegionMetadata(
                    json.optString("type", "legacy"),
                    json.optString("stableId", ""),
                    json.optString("name", "Offline region"),
                    json.optString("styleUrl", ""),
                    json.optLong("createdAt", 0L),
                    json.optLong("updateRequestedAt", 0L)
            );
        } catch (Exception ignored) {
            return new OfflineRegionMetadata("legacy", "", "Legacy offline region", "", 0L, 0L);
        }
    }

    public OfflineRegionMetadata withUpdateRequestedNow() {
        return new OfflineRegionMetadata(type, stableId, name, styleUrl, createdAt, System.currentTimeMillis());
    }

    public byte[] toBytes() {
        JSONObject json = new JSONObject();
        try {
            json.put("schema", SCHEMA_VERSION);
            json.put("type", type);
            json.put("stableId", stableId);
            json.put("name", name);
            json.put("styleUrl", styleUrl);
            json.put("createdAt", createdAt);
            json.put("updateRequestedAt", updateRequestedAt);
        } catch (Exception impossible) {
            throw new IllegalStateException(impossible);
        }
        return json.toString().getBytes(StandardCharsets.UTF_8);
    }
}
