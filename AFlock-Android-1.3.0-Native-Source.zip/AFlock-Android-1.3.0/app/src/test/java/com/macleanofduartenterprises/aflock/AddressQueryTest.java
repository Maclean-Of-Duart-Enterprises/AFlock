package com.macleanofduartenterprises.aflock;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class AddressQueryTest {
    @Test
    public void createsSafePrefixQuery() {
        assertEquals("\"101\"* AND \"old\"* AND \"mountain\"* AND \"road\"*",
                AddressQuery.toFtsPrefixQuery("101 Old Mountain Road"));
    }

    @Test
    public void preservesUnicodeLetters() {
        assertEquals("\"москва\"*", AddressQuery.toFtsPrefixQuery("Москва"));
    }

    @Test
    public void ignoresPunctuationOnlyInput() {
        assertEquals("", AddressQuery.toFtsPrefixQuery("---"));
    }
}
