package com.macleanofduartenterprises.aflock;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public final class ThemeManagerTest {
    @Test
    public void supportedThemeChoicesArePreserved() {
        assertEquals(ThemeManager.SYSTEM, ThemeManager.normalizeChoice(ThemeManager.SYSTEM));
        assertEquals(ThemeManager.LIGHT, ThemeManager.normalizeChoice(ThemeManager.LIGHT));
        assertEquals(ThemeManager.DARK, ThemeManager.normalizeChoice(ThemeManager.DARK));
    }

    @Test
    public void missingOrUnknownThemeChoiceUsesSystem() {
        assertEquals(ThemeManager.SYSTEM, ThemeManager.normalizeChoice(null));
        assertEquals(ThemeManager.SYSTEM, ThemeManager.normalizeChoice("sepia"));
    }
}
