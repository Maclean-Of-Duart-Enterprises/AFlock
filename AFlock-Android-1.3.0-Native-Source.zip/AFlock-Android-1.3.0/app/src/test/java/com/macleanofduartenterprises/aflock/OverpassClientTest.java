package com.macleanofduartenterprises.aflock;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.HashSet;
import java.util.List;
import org.junit.After;
import org.junit.Test;

public class OverpassClientTest {
    @After
    public void resetClientState() {
        OverpassClient.resetStateForTests();
    }

    @Test
    public void parsesRetryAfterSeconds() {
        assertEquals(
                120_000L,
                OverpassClient.parseRetryAfterMillis("120", 0L, 60_000L)
        );
    }

    @Test
    public void parsesRetryAfterHttpDate() {
        long now = 1_700_000_000_000L;
        assertEquals(
                120_000L,
                OverpassClient.parseRetryAfterMillis(
                        "Tue, 14 Nov 2023 22:15:20 GMT",
                        now,
                        60_000L
                )
        );
    }

    @Test
    public void clampsUnreasonableRetryAfter() {
        assertEquals(
                86_400_000L,
                OverpassClient.parseRetryAfterMillis("999999999", 0L, 60_000L)
        );
        assertEquals(
                1_000L,
                OverpassClient.parseRetryAfterMillis("0", 0L, 60_000L)
        );
    }

    @Test
    public void invalidRetryAfterUsesFallback() {
        assertEquals(
                45_000L,
                OverpassClient.parseRetryAfterMillis("not-a-date", 0L, 45_000L)
        );
    }

    @Test
    public void retriesOnlyTransientHttpStatuses() {
        assertTrue(OverpassClient.isRetryableStatus(408));
        assertTrue(OverpassClient.isRetryableStatus(429));
        assertTrue(OverpassClient.isRetryableStatus(500));
        assertTrue(OverpassClient.isRetryableStatus(502));
        assertTrue(OverpassClient.isRetryableStatus(503));
        assertTrue(OverpassClient.isRetryableStatus(504));
        assertFalse(OverpassClient.isRetryableStatus(400));
        assertFalse(OverpassClient.isRetryableStatus(401));
        assertFalse(OverpassClient.isRetryableStatus(404));
    }

    @Test
    public void usesDistinctCurrentGlobalEndpoints() {
        List<String> endpoints = OverpassClient.endpointsForTests();
        assertEquals(3, endpoints.size());
        assertEquals(endpoints.size(), new HashSet<>(endpoints).size());
        assertTrue(endpoints.get(0).contains("overpass.private.coffee"));
        for (String endpoint : endpoints) {
            assertTrue(endpoint.startsWith("https://"));
            assertFalse(endpoint.contains("overpass.kumi.systems"));
        }
    }
}
