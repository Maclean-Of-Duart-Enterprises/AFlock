package com.macleanofduartenterprises.aflock;

import org.junit.Test;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class WorldRegionCatalogTest {
    @Test
    public void catalogHasStableUniqueGlobalGrid() {
        List<WorldRegionCatalog.WorldRegion> regions = WorldRegionCatalog.detailedRegions(12);
        assertEquals(72, regions.size());
        Set<String> ids = new HashSet<>();
        for (WorldRegionCatalog.WorldRegion region : regions) {
            assertTrue(ids.add(region.id));
            assertTrue(region.south < region.north);
            assertTrue(region.west < region.east);
            assertEquals(12.0, region.maximumZoom, 0.0);
        }
    }

    @Test
    public void representativeCoordinatesAreCovered() {
        double[][] coordinates = {
                {40.34, -76.42},
                {51.5074, -0.1278},
                {-33.8688, 151.2093},
                {35.6762, 139.6503},
                {0.0, 0.0},
                {84.9, 179.9},
                {-84.9, -179.9}
        };
        for (double[] coordinate : coordinates) {
            assertNotNull(WorldRegionCatalog.findRegion(coordinate[0], coordinate[1], 12));
        }
    }

    @Test
    public void overviewCoversMercatorWorld() {
        WorldRegionCatalog.WorldRegion overview = WorldRegionCatalog.worldOverview();
        assertEquals(-180.0, overview.west, 0.0);
        assertEquals(180.0, overview.east, 0.0);
        assertEquals(0.0, overview.minimumZoom, 0.0);
        assertEquals(5.0, overview.maximumZoom, 0.0);
    }
}
