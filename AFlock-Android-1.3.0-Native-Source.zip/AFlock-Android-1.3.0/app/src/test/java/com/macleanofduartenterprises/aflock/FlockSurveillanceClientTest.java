package com.macleanofduartenterprises.aflock;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class FlockSurveillanceClientTest {
    @Test
    public void parsesAllPublishedTsvFields() {
        String line = "37.660361\t-122.489846\tfalcon\tinService\t1\t"
                + "#02 Pacific Pointe (Outbound)\t"
                + "livestream,readsLicensePlates,supportsVehicleDescriptionAlerts\t88.1\t"
                + "123\text-1\tnet-ext-1\torg-1\tnet-1\t"
                + "2024-03-26T18:02:45.611000+00:00\tparent-1";

        FlockSurveillanceClient.Device device =
                FlockSurveillanceClient.parseCameraLine(line);

        assertNotNull(device);
        assertEquals(37.660361d, device.latitude, 0.000001d);
        assertEquals(-122.489846d, device.longitude, 0.000001d);
        assertEquals("falcon", device.type);
        assertEquals("inService", device.status);
        assertTrue(device.active);
        assertEquals("#02 Pacific Pointe (Outbound)", device.name);
        assertEquals("88.1", device.rotationAngle);
        assertEquals("123", device.objectId);
        assertEquals("ext-1", device.externalId);
        assertEquals("net-ext-1", device.networkExternalId);
        assertEquals("org-1", device.organizationId);
        assertEquals("net-1", device.networkId);
        assertEquals("parent-1", device.parentExternalId);
    }

    @Test
    public void rejectsHeadersMalformedRowsAndInvalidCoordinates() {
        assertNull(FlockSurveillanceClient.parseCameraLine(
                "lat\tlon\ttype\tstatus\tactive\tname\tfeatures\trotationAngle\t"
                        + "OBJECTID\texternalId\tnetworkExternalId\torganizationId\t"
                        + "networkId\tCreationDate\tparentExternalId"));
        assertNull(FlockSurveillanceClient.parseCameraLine("1\t2\ttoo-short"));
        assertNull(FlockSurveillanceClient.parseCameraLine(
                "91\t2\tfalcon\tinService\t1\tname\tfeatures\t0\t1\t\t\t\t\t\t"));
    }

    @Test
    public void parsesCuratedUniqueEntriesAndDetentionExamples() {
        String html = "const cameras = ["
                + "{ title: \"FBI Pilot Camera\", lat: 38.89556, lon: -77.02496, "
                + "flags: [\"fbi\"], note: \"FBI-labeled camera\", featured: true },"
                + "detentionExample(\"254411\", \"All - Bond Vestibule Facing Detention\", "
                + "41.974752, -87.864975)];";

        FlockSurveillanceClient.UniqueCatalog catalog =
                FlockSurveillanceClient.parseUniqueHtml(html);

        assertEquals(2, catalog.size());
        FlockSurveillanceClient.Device fbi = new FlockSurveillanceClient.Device();
        fbi.name = "FBI Pilot Camera";
        FlockSurveillanceClient.UniqueEntry fbiEntry = catalog.match(fbi);
        assertNotNull(fbiEntry);
        assertEquals("Named example, FBI", fbiEntry.categories);
        assertEquals("FBI-labeled camera", fbiEntry.note);

        FlockSurveillanceClient.Device detention = new FlockSurveillanceClient.Device();
        detention.objectId = "254411";
        detention.name = "Different label";
        FlockSurveillanceClient.UniqueEntry detentionEntry = catalog.match(detention);
        assertNotNull(detentionEntry);
        assertEquals("Named example, Jail/prison/detention", detentionEntry.categories);
    }

    @Test
    public void handlesDateLineBoundsAndHumanReadableTypes() {
        FlockSurveillanceClient.Bounds bounds =
                new FlockSurveillanceClient.Bounds(-10d, 170d, 10d, -170d);
        assertTrue(bounds.contains(0d, 179d));
        assertTrue(bounds.contains(0d, -179d));
        assertFalse(bounds.contains(0d, 0d));
        assertEquals("Wing PTZ", FlockSurveillanceClient.humanType("wing"));
        assertEquals("Drone Dock", FlockSurveillanceClient.humanType("droneDockingStation"));
    }
}
