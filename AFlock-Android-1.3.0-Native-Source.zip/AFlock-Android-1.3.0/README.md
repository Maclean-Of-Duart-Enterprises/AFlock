# AFlock 1.3.0 — Android native surveillance and offline mapping

AFlock is an independent native Android application for displaying surveillance-device records and preparing maps, places, and addresses for use without a connection. The application is not affiliated with flocksurveillance.org; it loads the site's current published map data at runtime and keeps a local cache for offline use.

## Application identity

- Application ID: `com.macleanofduartenterprises.AFlock`
- Source namespace: `com.macleanofduartenterprises.aflock`
- Minimum Android version: Android 8.0 (API 26)
- Target/compile SDK: 35
- Version: 1.3.0 (`versionCode` 15)

Because the requested application ID contains an uppercase `AFlock`, Android treats it as different from the earlier all-lowercase 1.1.0 application ID.

## Completed offline-map resources

### Worldwide offline map

- A bundled Natural Earth vector overview renders the entire Web-Mercator world with no connection and no provider account.
- A provider-neutral 72-zone global detail catalog covers every supported coordinate from 85.0511° north to 85.0511° south.
- A separate low-zoom world package covers zoom levels 0–5.
- Detail zones support selectable maximum zoom levels 8, 10, 12, and 14.
- Downloads are resumable through MapLibre's offline database and are stored on the device.
- The application requires the user to configure an HTTPS MapLibre style whose provider expressly permits offline downloads. It does not bulk-download OpenStreetMap's public raster tile servers.

The built-in map is deliberately low-detail so that worldwide coverage fits inside a practical APK. Street-level worldwide data is downloaded only for selected zones; a complete street-level planet dataset would require very large storage and bandwidth.

### Offline address search

- A compressed GeoNames worldwide populated-place index is bundled in the APK and indexed into on-device SQLite FTS on first use.
- Searches are local and make no network request.
- Search supports names, aliases, streets, cities, state/region codes, postcodes, and country codes.
- Detailed OpenStreetMap street, house-number, place, amenity, and shop records can be downloaded for the current map area and then searched offline.
- Selecting a search result returns to the map at the saved coordinates.
- Detailed address downloads are deliberately bounded to 0.5° × 0.5° to protect the device and public Overpass infrastructure.

### Incremental vector-map updates

- A single region or all installed regions can be updated manually.
- MapLibre cache invalidation revalidates stored resources with the configured provider and retains unchanged data instead of deleting and redownloading the region.
- Optional weekly WorkManager updates run only on an unmetered network and when the battery is not low.
- Region metadata records stable catalog IDs and update-request timestamps.
- Strict offline mode prevents network updates until the user disables it.

## Other features

- Automatic startup loading from the dataset used by `https://flocksurveillance.org/index.html`
- Six-hour conditional local cache with explicit refresh and stale-cache fallback
- All 15 published camera fields, including device type, status, features, identifiers, rotation, and creation date
- Unique Cameras classifications and notes from `https://flocksurveillance.org/unique.html`
- A Unique display filter, highlighted markers, nearby-device labels, and dense-coordinate-cluster cautions
- OpenStreetMap surveillance records retained as an optional supplementary source and network fallback
- Compact map header with Settings gear, record search, and display-type filter
- Scrollable Settings panel containing map, synchronization, search, storage, and offline-map actions
- User-selectable device, light, or dark appearance
- System-bar-safe layouts with visible top and bottom borders on every screen
- Source-aware surveillance filtering, markers, details, background synchronization, and persistent local cache
- Periodic background surveillance-record synchronization
- Offline search of synchronized surveillance records
- Import and display osmdroid-compatible raster ZIP archives
- Resumable HTTPS raster/package downloads
- SHA-256 verification for user-supplied offline packages
- Storage and coverage management
- MapLibre region creation, download progress, deletion, coverage checking, and strict offline mode

## Data notices

- Natural Earth country geometry is public-domain data.
- The bundled GeoNames index is CC BY 4.0; data © GeoNames contributors.
- Camera records loaded from flocksurveillance.org remain subject to the source site's notices and any applicable underlying-data terms; the live TSV and Unique Cameras page are not bundled in the APK.
- OpenStreetMap-derived records are © OpenStreetMap contributors and licensed under ODbL.
- External style and tile-provider terms apply to detailed vector downloads.

See `app/src/main/assets/DATA-LICENSES.txt` for the complete notices.

## Privacy and operational behavior

- Offline address queries stay on the device.
- Detailed address data is downloaded only when the user explicitly requests the current area.
- Strict offline mode disables MapLibre network access.
- Application backups and device-transfer extraction are disabled because stored maps and local location indexes can be large or sensitive.
- Surveillance records can be incomplete, stale, generalized, or inaccurate. Dense same-coordinate clusters may be placeholders and are review leads rather than proof of exact device placement.
- Online OpenStreetMap data requests are serialized and rate-limited locally. If a public Overpass service returns HTTP 429 or a transient server error, AFlock observes its cooldown and automatically tries another listed global public instance.

## License

Application source is provided under the MIT License in `LICENSE`. Bundled and downloaded datasets retain their separate licenses described above.

## Building

The complete Gradle wrapper is included. See `BUILD.md` for tested build, signing, and verification commands.
