# AFlock 1.3.0 build, sign, and verify

## Requirements

- JDK 17
- Android SDK Platform 35
- Android SDK Build Tools 35.0.0 (34.0.0 is also accepted by AGP)
- Internet access for the first dependency download

The complete Gradle 8.9 wrapper is included.

## Compile and test

```sh
./gradlew clean testDebugUnitTest lintDebug assembleRelease
```

Unsigned release output:

```text
app/build/outputs/apk/release/app-release-unsigned.apk
```

## Align and sign

Never commit a private keystore or its passwords to source control. The commands below assume Build Tools 35.0.0 and a keystore copied to `signature/release.keystore`.

```sh
mkdir -p dist
$ANDROID_SDK_ROOT/build-tools/35.0.0/zipalign -f -p 4 \
  app/build/outputs/apk/release/app-release-unsigned.apk \
  dist/AFlock-Android-1.3.0-aligned.apk

$ANDROID_SDK_ROOT/build-tools/35.0.0/apksigner sign \
  --ks signature/release.keystore \
  --ks-key-alias macleanphonerelease \
  --out dist/AFlock-Android-1.3.0-universal-signed.apk \
  dist/AFlock-Android-1.3.0-aligned.apk
```

`apksigner` securely prompts for the keystore and key passwords. Avoid placing passwords directly in a script or repository.

## Verify

```sh
$ANDROID_SDK_ROOT/build-tools/35.0.0/apksigner verify --verbose --print-certs \
  dist/AFlock-Android-1.3.0-universal-signed.apk

$ANDROID_SDK_ROOT/build-tools/35.0.0/aapt2 dump badging \
  dist/AFlock-Android-1.3.0-universal-signed.apk
```

Expected package and version:

```text
package: name='com.macleanofduartenterprises.AFlock' versionCode='15' versionName='1.3.0'
```

Expected signing certificate SHA-256 fingerprint for the supplied Maclean Phone release key:

```text
62:EB:B3:C5:D7:D7:22:B2:E1:17:4A:46:22:F7:59:39:26:20:45:79:08:4F:94:E1:11:51:EF:60:6B:32:D1:36
```

## Device checks

After installation, verify these flows on a physical Android device:

1. Start the app online and confirm the visible area automatically loads records from the Flock Surveillance map dataset.
2. Select the **Unique** display type and inspect a highlighted record's categories, notes, nearby-device labels, and coordinate caution.
3. Disconnect networking, restart the app, and confirm saved records remain searchable and the cached source dataset can still populate the map.
4. Open **Worldwide vector maps / offline regions** and confirm the bundled world overview renders in strict offline mode.
5. Open **Offline address search**, wait for the first-run GeoNames import, and search for several international cities.
6. Configure an offline-permitted MapLibre HTTPS style, download a small detail region, enable strict offline mode, and confirm it remains visible.

The build and JVM unit tests verify compilation, global catalog coverage, package assembly, and query normalization. Rendering, provider compatibility, and large regional download behavior still require a physical device and a provider-authorized style.
