# Changelog

## 1.3.0

- Made the camera dataset used by `flocksurveillance.org/index.html` the default live source and load it automatically at startup.
- Added a bounded on-device source cache, conditional refresh, explicit refresh control, and saved-cache fallback.
- Parsed and retained all 15 published TSV fields for marker details and offline search.
- Integrated the curated classifications, notes, co-located labels, and coordinate cautions from the Unique Cameras page.
- Added ALPR, camera/PTZ, audio, drone, Unique, and Other display filters.
- Updated foreground loading and daily background sync to prefer the Flock Surveillance dataset.
- Kept resilient OpenStreetMap/Overpass loading as an optional supplementary source and fallback.
- Added source-aware offline persistence, search results, attribution, source links, and storage controls.
- Added regression tests for the published TSV schema, curated Unique Cameras parsing, type labels, and date-line bounds.

## 1.2.2

- Replaced the tall map action stack with a compact header and a settings gear in the upper-left corner.
- Kept surveillance search and display-type filtering directly in the map header.
- Moved data loading, synchronization, offline search, storage, and offline-map actions into a scrollable Settings panel.
- Added persistent Device, Light, and Dark appearance choices.
- Added system-bar insets and visible top/bottom borders to prevent controls and map content from sitting beneath status or navigation bars.
- Retained the Overpass endpoint failover, cooldown, and retry behavior introduced in 1.2.1.

## 1.2.1

- Replaced the legacy `overpass.kumi.systems` address with its current successor.
- Added automatic failover across three listed global public Overpass instances.
- Added `Retry-After` handling and per-service cooldowns for HTTP 429 responses.
- Added bounded handling for transient HTTP 408/5xx errors and network timeouts.
- Serialized app requests and added a two-second minimum request interval to prevent self-inflicted rate limiting.
- Prevented repeated taps from starting concurrent surveillance queries.
- Applied the same resilient transport to foreground surveillance loads, scheduled synchronization, and detailed offline-address packs.
- Added clearer progress and exhaustion messages instead of exposing a raw HTTP 429 failure.

## 1.2.0

- Added a bundled no-network worldwide Natural Earth vector overview.
- Added a stable 72-zone detail catalog covering the full Web-Mercator world.
- Added low-zoom worldwide and selectable detail-region downloads.
- Added a bundled GeoNames worldwide offline place index.
- Added SQLite FTS offline address/place search.
- Added bounded OpenStreetMap detailed address-pack downloads for visible areas.
- Added map navigation from offline address results.
- Added manual single/all-region cache revalidation updates.
- Added optional weekly unmetered incremental vector updates with WorkManager.
- Added stable offline-region metadata and update timestamps.
- Added map data attributions and backup/data-transfer exclusions.
- Added a complete Gradle wrapper, unit tests, an application icon, and release documentation.
- Corrected compile failures in raster import, osmdroid archive handling, receiver lifecycle, and MapLibre region IDs.
- Changed the application ID to `com.macleanofduartenterprises.AFlock` as requested.
